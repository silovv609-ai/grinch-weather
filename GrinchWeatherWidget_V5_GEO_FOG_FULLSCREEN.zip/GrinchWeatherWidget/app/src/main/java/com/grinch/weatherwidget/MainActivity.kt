package com.grinch.weatherwidget

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.concurrent.thread

/** Fullscreen forecast with 7-day swipeable hourly timeline + 14-day summary. */
class MainActivity : Activity() {
    private lateinit var cityTitle: TextView
    private lateinit var temperature: TextView
    private lateinit var conditions: TextView
    private lateinit var currentWind: TextView
    private lateinit var currentRain: TextView
    private lateinit var icon: WeatherIconView
    private lateinit var status: TextView
    private lateinit var hourlyTimeline: HourlyTimelineView
    private lateinit var hourlyScroll: HorizontalScrollView
    private lateinit var dayTabsScroll: HorizontalScrollView
    private lateinit var dayTabs: LinearLayout
    private lateinit var dayLabel: TextView
    private lateinit var dailyRows: LinearLayout
    private lateinit var swipe: SwipeRefreshLayout

    private val dayDates = mutableListOf<LocalDate>()
    private val dayButtons = mutableListOf<TextView>()
    private val forecastHours = mutableListOf<WeatherApi.Hour>()
    private var selectedDay = -1
    private var displayedKey: String? = null
    private var requestSerial = 0
    private var lastSuccessAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (WidgetRefreshScheduler.isEnabled(this@MainActivity)) {
                loadForecast(force = true)
                scheduleForegroundRefresh()
            }
        }
    }

    private fun dp(value: Float): Int = (resources.displayMetrics.density * value + .5f).toInt()
    private val uk: Locale get() = Locale.forLanguageTag("uk-UA")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 23, 38)
        window.navigationBarColor = Color.rgb(13, 23, 38)
        setContentView(R.layout.activity_main)

        cityTitle = findViewById(R.id.mainCity)
        temperature = findViewById(R.id.mainTemp)
        conditions = findViewById(R.id.mainCondition)
        currentWind = findViewById(R.id.mainWind)
        currentRain = findViewById(R.id.mainRain)
        icon = findViewById(R.id.mainIcon)
        status = findViewById(R.id.mainStatus)
        hourlyTimeline = findViewById(R.id.hourlyTimeline)
        hourlyScroll = findViewById(R.id.hourlyScroll)
        dayTabsScroll = findViewById(R.id.dayTabsScroll)
        dayTabs = findViewById(R.id.dayTabs)
        dayLabel = findViewById(R.id.selectedDayLabel)
        dailyRows = findViewById(R.id.dailyRows)
        swipe = findViewById(R.id.pullToRefresh)

        swipe.setColorSchemeColors(Color.rgb(120, 224, 239))
        swipe.setProgressBackgroundColorSchemeColor(Color.rgb(29, 45, 62))
        swipe.setOnRefreshListener { loadForecast(force = true) }

        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }
        val openExpanded = View.OnClickListener {
            startActivity(Intent(this, HourlyDetailActivity::class.java))
        }
        findViewById<View>(R.id.heroCard).setOnClickListener(openExpanded)
        findViewById<TextView>(R.id.expandHourlyButton).setOnClickListener(openExpanded)
        hourlyTimeline.setOnClickListener(openExpanded)
        hourlyScroll.setOnClickListener(openExpanded)
        hourlyScroll.setOnScrollChangeListener { _: View, scrollX: Int, _: Int, _: Int, _: Int ->
            updateDayForScroll(scrollX)
        }
        WidgetRefreshScheduler.ensureScheduled(this)
    }

    override fun onResume() {
        super.onResume()
        val expiryMs = WidgetRefreshScheduler.intervalHours(this).toLong() * 3_600_000L
        val stale = WidgetRefreshScheduler.isEnabled(this) && lastSuccessAt != 0L &&
            SystemClock.elapsedRealtime() - lastSuccessAt >= expiryMs
        loadForecast(force = stale)
        if (WeatherPlaces.isGeoEnabled(this) && LocationHelper.hasPermission(this)) {
            LocationHelper.request(this) { location ->
                if (location != null && !isFinishing && !isDestroyed) {
                    val previous = WeatherPlaces.current(this)
                    if (previous == null ||
                        kotlin.math.abs(previous.latitude - location.latitude) > .004 ||
                        kotlin.math.abs(previous.longitude - location.longitude) > .004) {
                        WeatherPlaces.saveGeoCoordinates(this, location.latitude, location.longitude)
                        loadForecast(force = true)
                    }
                }
            }
        }
        scheduleForegroundRefresh()
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun scheduleForegroundRefresh() {
        handler.removeCallbacks(tick)
        if (WidgetRefreshScheduler.isEnabled(this)) {
            val delay = WidgetRefreshScheduler.intervalHours(this).toLong() * 3_600_000L
            handler.postDelayed(tick, delay)
        }
    }

    private fun currentKey(): String {
        val place = WeatherPlaces.current(this)
        return if (place != null) {
            "${if (WeatherPlaces.isGeoEnabled(this)) "geo" else "manual"}:${place.latitude}:${place.longitude}"
        } else if (WeatherPlaces.isGeoEnabled(this)) {
            "geo:pending"
        } else {
            "legacy:${WeatherPlaces.manualCity(this)}"
        }
    }

    private fun loadForecast(force: Boolean) {
        val key = currentKey()
        if (key == "legacy:" || key == "geo:pending") {
            displayedKey = null
            cityTitle.text = if (key == "geo:pending") "Моя геолокація" else "Оберіть місто"
            status.text = if (key == "geo:pending") "Чекаємо координати. Перевір геолокацію в ⚙"
                          else "Вибери населений пункт через ⚙"
            swipe.isRefreshing = false
            return
        }
        if (!force && key == displayedKey && lastSuccessAt > 0L) {
            swipe.isRefreshing = false
            return
        }
        val changed = key != displayedKey
        displayedKey = key
        cityTitle.text = WeatherPlaces.current(this)?.name ?: WeatherPlaces.manualCity(this)
        status.text = "Завантаження прогнозу…"
        if (force) swipe.isRefreshing = true
        if (changed) {
            forecastHours.clear()
            dayDates.clear()
            dayTabs.removeAllViews()
            dayButtons.clear()
            dailyRows.removeAllViews()
        }
        val requestId = ++requestSerial
        thread(name = "Grinch7DayForecast") {
            try {
                val forecast = WeatherApi.fetch(applicationContext)
                runOnUiThread {
                    if (requestId != requestSerial || isFinishing || isDestroyed) return@runOnUiThread
                    ForecastState.last = forecast
                    render(forecast, changed)
                    lastSuccessAt = SystemClock.elapsedRealtime()
                    swipe.isRefreshing = false
                    WidgetRefreshScheduler.refreshNow(this)
                }
            } catch (error: Exception) {
                android.util.Log.e("GrinchWeather", "Could not load weather", error)
                runOnUiThread {
                    if (requestId != requestSerial || isFinishing || isDestroyed) return@runOnUiThread
                    swipe.isRefreshing = false
                    status.text = "Помилка оновлення: ${error.message ?: "перевір інтернет"}"
                }
            }
        }
    }

    private fun render(f: WeatherApi.Forecast, changedCity: Boolean) {
        cityTitle.text = f.city
        temperature.text = "${f.temperature}°"
        icon.setWeather(f.code, f.isDay)
        conditions.text = "${f.description}  ·  відчувається ${f.feelsLike}°"
        currentWind.text = "Вітер ${WeatherApi.speed(f.wind)} м/с  ${WeatherApi.arrow(f.windDegrees)}"
        currentRain.text = "Опади зараз  ${WeatherApi.mm(f.precipitation)} мм"
        status.text = if (f.cached) "Офлайн: показано останній збережений прогноз"
                      else "Оновлено · потягни вниз для нового прогнозу"

        val shouldResetPosition = changedCity || forecastHours.isEmpty()
        val previousX = hourlyScroll.scrollX
        forecastHours.clear()
        forecastHours.addAll(f.hours)
        hourlyTimeline.setForecast(f.hours, f.currentTime, f.days)
        dayDates.clear()
        dayDates.addAll(f.hours.map { it.time.toLocalDate() }.distinct())
        makeDayTabs()
        if (shouldResetPosition) {
            // Open at the current hour, leaving earlier today available when swiping back.
            val currentIndex = f.hours.indexOfFirst { !it.time.isBefore(f.currentTime.withMinute(0).withSecond(0).withNano(0)) }
                .coerceAtLeast(0)
            hourlyScroll.post { hourlyScroll.scrollTo(currentIndex * hourlyTimeline.columnWidthPx, 0)
                updateDayForScroll(hourlyScroll.scrollX) }
        } else {
            hourlyScroll.post { hourlyScroll.scrollTo(previousX, 0)
                updateDayForScroll(hourlyScroll.scrollX) }
        }
        renderDaily(f.days)
    }

    private fun makeDayTabs() {
        dayTabs.removeAllViews()
        dayButtons.clear()
        selectedDay = -1
        for ((index, date) in dayDates.withIndex()) {
            val dateStr = date.format(DateTimeFormatter.ofPattern("dd.MM", uk))
            val label = if (index == 0) "Сьогодні\n$dateStr" else
                "${date.format(DateTimeFormatter.ofPattern("EE", uk)).replaceFirstChar { it.uppercase() }}\n$dateStr"
            val button = TextView(this).apply {
                text = label
                gravity = android.view.Gravity.CENTER
                setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(Color.rgb(197, 218, 233))
                setPadding(dp(16f), dp(10f), dp(16f), dp(10f))
                setBackgroundResource(R.drawable.chip_unselected_bg)
                setOnClickListener {
                    val hourIndex = forecastHours.indexOfFirst { it.time.toLocalDate() == date }
                    if (hourIndex >= 0) hourlyScroll.smoothScrollTo(hourIndex * hourlyTimeline.columnWidthPx, 0)
                    selectDay(index)
                }
            }
            dayTabs.addView(button, LinearLayout.LayoutParams(dp(88f), dp(59f)).apply {
                rightMargin = dp(7f)
            })
            dayButtons.add(button)
        }
    }

    private fun updateDayForScroll(scrollX: Int) {
        if (forecastHours.isEmpty() || dayDates.isEmpty()) return
        val currentHourIndex = (scrollX / hourlyTimeline.columnWidthPx)
            .coerceIn(0, forecastHours.lastIndex)
        val date = forecastHours[currentHourIndex].time.toLocalDate()
        val dayIndex = dayDates.indexOf(date)
        if (dayIndex >= 0) selectDay(dayIndex)
    }

    private fun selectDay(index: Int) {
        if (index !in dayDates.indices || selectedDay == index) return
        selectedDay = index
        val date = dayDates[index]
        dayLabel.text = if (index == 0) {
            "Сьогодні, ${date.format(DateTimeFormatter.ofPattern("d MMMM", uk))}"
        } else {
            date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", uk))
                .replaceFirstChar { it.uppercase() }
        }
        for (i in dayButtons.indices) {
            dayButtons[i].setBackgroundResource(
                if (i == index) R.drawable.chip_selected_bg else R.drawable.chip_unselected_bg
            )
            dayButtons[i].setTextColor(
                if (i == index) Color.rgb(12, 36, 46) else Color.rgb(197, 218, 233)
            )
        }
        dayTabsScroll.smoothScrollTo(dayButtons[index].left - dp(14f), 0)
    }

    private fun renderDaily(days: List<WeatherApi.Day>) {
        dailyRows.removeAllViews()
        for (day in days) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(15f), dp(13f), dp(15f), dp(13f))
                setBackgroundResource(R.drawable.daily_card_bg)
            }
            val head = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            val dayName = day.date.format(DateTimeFormatter.ofPattern("EE, dd.MM", uk))
                .replaceFirstChar { it.uppercase() }
            head.addView(label(dayName, 16f, 0xFFE9F4FC.toInt(), true),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val glyph = WeatherIconView(this).apply { setWeather(day.code) }
            head.addView(glyph, LinearLayout.LayoutParams(dp(38f), dp(38f)))
            head.addView(label("${day.max}°", 21f, 0xFFFFD79F.toInt(), true).apply {
                gravity = android.view.Gravity.END
            }, LinearLayout.LayoutParams(dp(58f), LinearLayout.LayoutParams.WRAP_CONTENT))
            head.addView(label("${day.min}°", 16f, 0xFF9EB3C9.toInt()).apply {
                gravity = android.view.Gravity.END
            }, LinearLayout.LayoutParams(dp(48f), LinearLayout.LayoutParams.WRAP_CONTENT))
            card.addView(head)
            card.addView(label(
                "Опади ${WeatherApi.mm(day.precipitation)} мм · ${day.rain}%",
                13f, 0xFF88DAEC.toInt()
            ).apply { setPadding(0, dp(5f), 0, 0) })
            card.addView(label(
                "Вітер  ${WeatherApi.arrow(day.degrees)}  ${WeatherApi.speed(day.wind)} м/с",
                13f, 0xFFB7C9DA.toInt()
            ).apply { setPadding(0, dp(3f), 0, 0) })
            card.addView(label(
                "Туман: орієнтовний ризик ${day.fogRisk}%*",
                13f, 0xFF9CE4DD.toInt()
            ).apply { setPadding(0, dp(4f), 0, 0) })

            dailyRows.addView(card, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8f) })
        }
    }

    private fun label(value: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            setTextColor(color)
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, sp)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
}
