package com.grinch.weatherwidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import java.time.LocalDate
import java.time.LocalDateTime
import kotlin.math.roundToInt

/** Seven calendar days, one column per hour. Two temperature lines are daily daytime MAX and night MIN. */
class HourlyTimelineView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val hours = ArrayList<WeatherApi.Hour>()
    private val daily = HashMap<LocalDate, WeatherApi.Day>()
    private var currentTime: LocalDateTime? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = Rect()
    private val density = resources.displayMetrics.density
    private val scaled = resources.displayMetrics.scaledDensity
    private var expanded = false
    private val warm = Color.rgb(255, 210, 147)
    private val sea = Color.rgb(123, 223, 208)
    private val white = Color.rgb(247, 251, 255)
    private val light = Color.rgb(161, 184, 203)
    private val teal = Color.rgb(133, 226, 239)

    private val column: Float get() = (if (expanded) 128f else 116f) * density
    val columnWidthPx: Int get() = column.roundToInt()

    fun setExpanded(value: Boolean) { expanded = value; requestLayout(); invalidate() }

    fun setForecast(data: List<WeatherApi.Hour>, now: LocalDateTime, days: List<WeatherApi.Day>) {
        hours.clear(); hours.addAll(data)
        daily.clear(); days.forEach { daily[it.date] = it }
        currentTime = now
        requestLayout(); invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (hours.size.coerceAtLeast(3) * column + 16f * density).roundToInt()
        val h = ((if (expanded) 466f else 443f) * density).roundToInt()
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    private fun x(i: Int): Float = 8f * density + (i + .5f) * column
    private fun y(dp: Float): Float = dp * density

    private fun drawText(canvas: Canvas, string: String, x: Float, baseline: Float,
                         size: Float, color: Int, bold: Boolean = false) {
        p.reset(); p.isAntiAlias = true
        p.color = color; p.textSize = size * scaled; p.textAlign = Paint.Align.CENTER
        p.typeface = android.graphics.Typeface.create(
            if (bold) "sans-serif-medium" else "sans-serif", android.graphics.Typeface.NORMAL)
        canvas.drawText(string, x, baseline, p)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (hours.isEmpty()) {
            drawText(canvas, "Очікування прогнозу…", width / 2f, y(180f), 15f, light)
            return
        }
        canvas.getClipBounds(bounds)
        val firstVisible = ((bounds.left - y(8f)) / column).toInt().coerceIn(0, hours.lastIndex)
        val lastVisible = ((bounds.right - y(8f)) / column).toInt().coerceIn(firstVisible, hours.lastIndex)
        val first = (firstVisible - 2).coerceAtLeast(0)
        val last = (lastVisible + 2).coerceAtMost(hours.lastIndex)

        val allLows = daily.values.map { it.min } + hours.map { it.temp }
        val allHighs = daily.values.map { it.max } + hours.map { it.temp }
        val minTemp = allLows.minOrNull() ?: 0
        val maxTemp = allHighs.maxOrNull() ?: 30
        val span = (maxTemp - minTemp).coerceAtLeast(5).toFloat()
        fun chartY(temp: Float): Float = y(272f) - (temp - minTemp) / span * y(117f)
        fun value(i: Int, dayTrack: Boolean): Float {
            val date = hours[i].time.toLocalDate()
            val current = daily[date]
            val next = daily[date.plusDays(1)] ?: current
            val a = if (dayTrack) current?.max else current?.min
            val b = if (dayTrack) next?.max else next?.min
            if (a == null) return hours[i].temp.toFloat()
            val factor = hours[i].time.hour / 24f
            return a + ((b ?: a) - a) * factor
        }
        fun daytime(i: Int) = value(i, true)
        fun night(i: Int) = value(i, false)

        for (i in first..last) {
            val entry = hours[i]
            val centerX = x(i)
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL
            if (!entry.isDay) {
                p.color = Color.rgb(26, 41, 61)
                canvas.drawRect(centerX - column / 2, y(4f), centerX + column / 2, height.toFloat(), p)
            }
            if (entry.time == currentTime?.withMinute(0)?.withSecond(0)?.withNano(0)) {
                p.color = Color.rgb(51, 82, 99)
                canvas.drawRoundRect(RectF(centerX - column * .46f, y(5f),
                    centerX + column * .46f, height - y(5f)), y(12f), y(12f), p)
            }
            if (entry.time.hour == 0 && i != 0) {
                p.style = Paint.Style.STROKE; p.color = Color.rgb(71, 100, 121)
                p.strokeWidth = y(1f)
                canvas.drawLine(centerX - column / 2, y(8f), centerX - column / 2, height - y(8f), p)
                drawText(canvas, entry.time.toLocalDate().toString().takeLast(5).replace('-', '.'),
                    centerX, y(15f), 10f, teal)
            }
            drawText(canvas, "%02d:00".format(entry.time.hour), centerX, y(38f), 13f, light)
            WeatherGlyph.draw(canvas, centerX, y(77f), y(18f), entry.code, entry.isDay, p)
            drawText(canvas, "${entry.temp}°", centerX, y(133f), 25f, white, true)
        }

        val graphStart = (first - 1).coerceAtLeast(0)
        val graphEnd = (last + 1).coerceAtMost(hours.lastIndex)
        fun drawTrack(isDay: Boolean) {
            val path = Path()
            for (i in graphStart..graphEnd) {
                val pointY = chartY(if (isDay) daytime(i) else night(i))
                if (i == graphStart) path.moveTo(x(i), pointY) else path.lineTo(x(i), pointY)
            }
            p.reset(); p.isAntiAlias = true; p.color = if (isDay) warm else sea
            p.style = Paint.Style.STROKE; p.strokeWidth = y(2.8f)
            p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
            canvas.drawPath(path, p)
            for (i in first..last) {
                if (hours[i].time.hour % 6 != 0 && hours[i].time.hour != 23) continue
                p.style = Paint.Style.FILL
                canvas.drawCircle(x(i), chartY(if (isDay) daytime(i) else night(i)), y(3.5f), p)
            }
        }
        drawTrack(true)
        drawTrack(false)
        for (i in first..last) {
            if (hours[i].time.hour == 12) {
                val at = hours[i].time.toLocalDate()
                val day = daily[at] ?: continue
                drawText(canvas, "${day.max}°", x(i), chartY(daytime(i)) - y(10f), 12f, warm, true)
                drawText(canvas, "${day.min}°", x(i), chartY(night(i)) + y(19f), 12f, sea, true)
            }
        }

        for (i in first..last) {
            val h = hours[i]
            val centerX = x(i)
            drawWindArrow(canvas, centerX - y(23f), y(323f), h.degrees)
            drawText(canvas, "${WeatherApi.speed(h.wind)} м/с", centerX + y(13f), y(329f),
                13f, white, true)
            drawText(canvas, "ПОРИВИ", centerX, y(360f), 10f, light, true)
            drawText(canvas, "${WeatherApi.speed(h.gust)} м/с", centerX, y(382f), 15f, teal, true)
            drawText(canvas, "${WeatherApi.mm(h.precipitation)} мм опадів", centerX, y(407f), 11f, light)
            drawText(canvas, "${h.rainChance}%", centerX, y(430f), 12f, teal, true)
        }
    }

    private fun drawWindArrow(canvas: Canvas, posX: Float, posY: Float, fromDegrees: Double) {
        canvas.save()
        canvas.rotate(((fromDegrees + 180.0) % 360.0).toFloat(), posX, posY)
        p.reset(); p.isAntiAlias = true; p.color = white; p.style = Paint.Style.STROKE
        p.strokeWidth = y(2.2f); p.strokeCap = Paint.Cap.ROUND
        val l = y(13f)
        canvas.drawLine(posX, posY + l * .55f, posX, posY - l * .75f, p)
        canvas.drawLine(posX, posY - l * .75f, posX - l * .4f, posY - l * .25f, p)
        canvas.drawLine(posX, posY - l * .75f, posX + l * .4f, posY - l * .25f, p)
        canvas.restore()
    }
}
