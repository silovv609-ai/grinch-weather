package com.grinch.weatherwidget

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.roundToInt

/** Neon-green dashboard. All values come from WeatherApi, not the design preview. */
class MainActivity : Activity() {
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var mainCity: TextView
    private lateinit var mainTemp: TextView
    private lateinit var mainCondition: TextView
    private lateinit var mainWind: TextView
    private lateinit var mainGust: TextView
    private lateinit var mainRain: TextView
    private lateinit var mainRainChance: TextView
    private lateinit var fog: TextView
    private lateinit var windStatus: TextView
    private lateinit var status: TextView
    private lateinit var icon: WeatherIconView
    private lateinit var hourlyStrip: LinearLayout
    private lateinit var dailyStrip: LinearLayout
    private lateinit var hourlyScroll: HorizontalScrollView
    private lateinit var dailyScroll: HorizontalScrollView
    private lateinit var sunrise: TextView
    private lateinit var sunset: TextView
    private lateinit var sunProgress: ProgressBar
    private lateinit var dayLength: TextView
    private lateinit var sunNow: TextView

    private var displayedKey: String? = null
    private var requestSerial = 0
    private var lastSuccessfulLoad = 0L
    private var lastForecast: WeatherApi.Forecast? = null
    private var sunFetchTime = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val uk = Locale.forLanguageTag("uk-UA")
    private val neon = Color.rgb(78, 247, 126)
    private val white = Color.rgb(243, 250, 244)
    private val muted = Color.rgb(168, 192, 175)
    private val red = Color.rgb(255, 103, 113)

    private val clockTick = object : Runnable {
        override fun run() {
            updateSunProgress()
            handler.postDelayed(this, 60_000L)
        }
    }
    private val refreshTick = object : Runnable {
        override fun run() {
            if (WidgetRefreshScheduler.isEnabled(this@MainActivity)) {
                loadForecast(true)
                scheduleAutoRefresh()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 12, 9)
        window.navigationBarColor = Color.rgb(5, 12, 9)
        setContentView(R.layout.activity_main)
        swipe = findViewById(R.id.pullToRefresh)
        mainCity = findViewById(R.id.mainCity)
        mainTemp = findViewById(R.id.mainTemp)
        mainCondition = findViewById(R.id.mainCondition)
        mainWind = findViewById(R.id.mainWind)
        mainGust = findViewById(R.id.mainGust)
        mainRain = findViewById(R.id.mainRain)
        mainRainChance = findViewById(R.id.mainRainChance)
        fog = findViewById(R.id.heroFog)
        windStatus = findViewById(R.id.windStatus)
        status = findViewById(R.id.mainStatus)
        icon = findViewById(R.id.mainIcon)
        hourlyStrip = findViewById(R.id.hourlyStrip)
        dailyStrip = findViewById(R.id.dailyStrip)
        hourlyScroll = findViewById(R.id.hourlyScroll)
        dailyScroll = findViewById(R.id.dailyScroll)
        sunrise = findViewById(R.id.sunriseTime)
        sunset = findViewById(R.id.sunsetTime)
        sunProgress = findViewById(R.id.sunProgress)
        dayLength = findViewById(R.id.dayLength)
        sunNow = findViewById(R.id.sunNow)
        swipe.setColorSchemeColors(neon)
        swipe.setProgressBackgroundColorSchemeColor(Color.rgb(13, 34, 22))
        swipe.setOnRefreshListener { loadForecast(true) }
        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener { openSettings() }
        windStatus.setOnClickListener { openSettings() }
        findViewById<View>(R.id.heroCard).setOnClickListener { openHourly() }
        findViewById<View>(R.id.expandHourlyButton).setOnClickListener { openHourly() }
        findViewById<View>(R.id.expandDailyButton).setOnClickListener {
            dailyScroll.smoothScrollTo(dailyScroll.scrollX + dp(320), 0)
        }
        WidgetRefreshScheduler.ensureScheduled(this)
    }

    override fun onResume() {
        super.onResume()
        val staleMs = WidgetRefreshScheduler.intervalHours(this).toLong() * 3_600_000L
        val stale = lastSuccessfulLoad != 0L &&
            SystemClock.elapsedRealtime() - lastSuccessfulLoad > staleMs
        loadForecast(stale)
        lastForecast?.let { updateWindIndicator(it.wind) }
        if (WeatherPlaces.isGeoEnabled(this) && LocationHelper.hasPermission(this)) {
            LocationHelper.request(this) { location ->
                if (location != null && !isFinishing && !isDestroyed) {
                    val previous = WeatherPlaces.current(this)
                    if (previous == null || abs(previous.latitude - location.latitude) > .004 ||
                        abs(previous.longitude - location.longitude) > .004) {
                        WeatherPlaces.saveGeoCoordinates(this, location.latitude, location.longitude)
                        loadForecast(true)
                    }
                }
            }
        }
        handler.removeCallbacks(clockTick)
        handler.post(clockTick)
        scheduleAutoRefresh()
    }

    override fun onPause() {
        handler.removeCallbacks(clockTick)
        handler.removeCallbacks(refreshTick)
        super.onPause()
    }

    private fun dp(v: Int): Int = (resources.displayMetrics.density * v + .5f).toInt()
    private fun openSettings() = startActivity(Intent(this, ConfigActivity::class.java))
    private fun openHourly() = startActivity(Intent(this, HourlyDetailActivity::class.java))

    private fun scheduleAutoRefresh() {
        handler.removeCallbacks(refreshTick)
        if (WidgetRefreshScheduler.isEnabled(this)) {
            handler.postDelayed(refreshTick,
                WidgetRefreshScheduler.intervalHours(this).toLong() * 3_600_000L)
        }
    }

    private fun currentKey(): String {
        val place = WeatherPlaces.current(this)
        return if (place != null) {
            "${if (WeatherPlaces.isGeoEnabled(this)) "geo" else "manual"}:${place.latitude}:${place.longitude}"
        } else if (WeatherPlaces.isGeoEnabled(this)) "geo:pending"
        else "legacy:${WeatherPlaces.manualCity(this)}"
    }

    private fun loadForecast(force: Boolean) {
        val key = currentKey()
        if (key == "legacy:" || key == "geo:pending") {
            mainCity.text = if (key == "geo:pending") "Моя геолокація" else "Оберіть місто"
            status.text = if (key == "geo:pending") "Увімкни геолокацію в ⚙"
                          else "Налаштуй місто або село через ⚙"
            swipe.isRefreshing = false
            return
        }
        if (!force && key == displayedKey && lastSuccessfulLoad > 0L) {
            swipe.isRefreshing = false
            return
        }
        val changed = key != displayedKey
        displayedKey = key
        val currentPlace = WeatherPlaces.current(this)
        mainCity.text = currentPlace?.name ?: WeatherPlaces.manualCity(this)
        status.text = "Оновлюємо прогноз…"
        if (force) swipe.isRefreshing = true
        if (changed) {
            lastForecast = null
            hourlyStrip.removeAllViews()
            dailyStrip.removeAllViews()
        }
        val request = ++requestSerial
        thread(name = "GrinchWeatherNeon") {
            try {
                val forecast = WeatherApi.fetch(applicationContext)
                runOnUiThread {
                    if (isFinishing || isDestroyed || request != requestSerial) return@runOnUiThread
                    ForecastState.last = forecast
                    lastForecast = forecast
                    sunFetchTime = SystemClock.elapsedRealtime()
                    lastSuccessfulLoad = sunFetchTime
                    render(forecast)
                    swipe.isRefreshing = false
                    WidgetRefreshScheduler.refreshNow(this)
                }
            } catch (error: Exception) {
                android.util.Log.e("GrinchWeather", "Weather loading failed", error)
                runOnUiThread {
                    if (isFinishing || isDestroyed || request != requestSerial) return@runOnUiThread
                    swipe.isRefreshing = false
                    status.text = "Не вдалося оновити: ${error.message ?: "перевір з’єднання"}"
                }
            }
        }
    }

    private fun render(f: WeatherApi.Forecast) {
        mainCity.text = f.city
        mainTemp.text = "${f.temperature}°"
        mainCondition.text = f.description
        icon.setWeather(f.code, f.isDay)
        mainWind.text = "${WeatherApi.speed(f.wind)} м/с ${WeatherApi.arrow(f.windDegrees)}"
        mainRain.text = "${WeatherApi.mm(f.precipitation)} мм"
        val currentHour = f.hours.firstOrNull {
            !it.time.isBefore(f.currentTime.withMinute(0).withSecond(0).withNano(0))
        }
        mainGust.text = "Пориви ${currentHour?.let { WeatherApi.speed(it.gust) } ?: "—"} м/с"
        mainRainChance.text = "Ймовірність ${currentHour?.rainChance ?: 0}%"
        fog.text = "≋ Ризик туману ${f.days.firstOrNull()?.fogRisk ?: 0}%*"
        updateWindIndicator(f.wind)
        status.text = if (f.cached) "Офлайн · показані останні збережені дані"
            else "Оновлено · потягни вниз для оновлення"
        renderHours(f)
        renderDays(f)
        updateSunProgress()
    }

    private fun updateWindIndicator(speed: Double) {
        val prefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        val threshold = prefs.getInt("drone_wind_limit", 10).coerceIn(1, 30)
        if (!prefs.getBoolean("drone_indicator_enabled", true)) {
            windStatus.visibility = View.GONE
            return
        }
        windStatus.visibility = View.VISIBLE
        val green = speed >= threshold
        windStatus.text = if (green) "ГОТОВО" else "НЕ ГОТОВО"
        windStatus.setBackgroundResource(if (green) R.drawable.neon_status_green else R.drawable.neon_status_red)
        windStatus.setTextColor(if (green) neon else red)
    }

    private fun label(textValue: String, sp: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = textValue
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun renderHours(f: WeatherApi.Forecast) {
        hourlyStrip.removeAllViews()
        val current = f.currentTime.withMinute(0).withSecond(0).withNano(0)
        val hours = f.hours.filter { !it.time.isBefore(current) }.take(24)
        for ((index, hour) in hours.withIndex()) {
            val isNow = index == 0
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(7), dp(4), dp(7))
                setBackgroundResource(if (isNow) R.drawable.neon_selected_bg else R.drawable.neon_tile_bg)
                isClickable = true
                isFocusable = true
                setOnClickListener { openHourly() }
            }
            card.addView(label(if (isNow) "Зараз" else hour.time.format(DateTimeFormatter.ofPattern("HH:mm")),
                11f, if (isNow) white else muted), LinearLayout.LayoutParams(-1, dp(27)))
            val weatherIcon = WeatherIconView(this).apply { setWeather(hour.code, hour.isDay) }
            card.addView(weatherIcon, LinearLayout.LayoutParams(dp(42), dp(45)))
            card.addView(label("${hour.temp}°", 19f, white, true), LinearLayout.LayoutParams(-1, dp(30)))
            card.addView(label("${WeatherApi.arrow(hour.degrees)} ${WeatherApi.speed(hour.wind)}", 12f, neon),
                LinearLayout.LayoutParams(-1, dp(24)))
            card.addView(label("П ${WeatherApi.speed(hour.gust)}", 10f, muted),
                LinearLayout.LayoutParams(-1, dp(19)))
            hourlyStrip.addView(card, LinearLayout.LayoutParams(dp(81), dp(148)).apply {
                rightMargin = dp(6)
            })
        }
        hourlyScroll.post { hourlyScroll.scrollTo(0, 0) }
    }

    private fun renderDays(f: WeatherApi.Forecast) {
        dailyStrip.removeAllViews()
        val maxWind = f.days.maxOfOrNull { it.wind } ?: 0.0
        for ((i, day) in f.days.withIndex()) {
            val strongest = maxWind > 0 && abs(day.wind - maxWind) < 0.001
            val date = day.date.format(DateTimeFormatter.ofPattern("dd.MM"))
            val title = if (i == 0) "Сьогодні" else day.date.format(DateTimeFormatter.ofPattern("EE", uk))
                .replaceFirstChar { it.uppercase() }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(6), dp(4), dp(6))
                setBackgroundResource(when {
                    strongest -> R.drawable.neon_red_bg
                    i == 0 -> R.drawable.neon_selected_bg
                    else -> R.drawable.neon_tile_bg
                })
                isClickable = true
                isFocusable = true
                setOnClickListener { showDayDetails(day, i < 7) }
                contentDescription = "${title} ${date}, вітер ${WeatherApi.speed(day.wind)} м/с"
            }
            card.addView(label(title, 12f, white, i == 0), LinearLayout.LayoutParams(-1, dp(24)))
            card.addView(label(date, 11f, if (strongest) red else muted), LinearLayout.LayoutParams(-1, dp(22)))
            val iconView = WeatherIconView(this).apply { setWeather(day.code) }
            card.addView(iconView, LinearLayout.LayoutParams(dp(46), dp(52)))
            card.addView(label("${day.max}° / ${day.min}°", 14f, white, true), LinearLayout.LayoutParams(-1, dp(29)))
            card.addView(label("${WeatherApi.arrow(day.degrees)} ${WeatherApi.speed(day.wind)}", 13f,
                if (strongest) red else neon), LinearLayout.LayoutParams(-1, dp(25)))
            card.addView(label("П ${WeatherApi.speed(day.gust)}", 11f,
                if (strongest) red else muted), LinearLayout.LayoutParams(-1, dp(20)))
            card.addView(label("☂ ${day.rain}%", 11f, muted), LinearLayout.LayoutParams(-1, dp(23)))
            dailyStrip.addView(card, LinearLayout.LayoutParams(dp(106), dp(196)).apply {
                rightMargin = dp(6)
            })
        }
        dailyScroll.post { dailyScroll.scrollTo(0, 0) }
    }

    private fun showDayDetails(day: WeatherApi.Day, hasHourlyForecast: Boolean) {
        val fogText = "Ризик туману: ~${day.fogRisk}% (орієнтовно)\n"
        val description = "Температура: ${day.min}…${day.max} °C\n" +
            "Вітер: ${WeatherApi.speed(day.wind)} м/с ${WeatherApi.arrow(day.degrees)}\n" +
            "Максимальні пориви: ${WeatherApi.speed(day.gust)} м/с\n" +
            "Опади: ${WeatherApi.mm(day.precipitation)} мм\n" +
            "Ймовірність опадів: ${day.rain}%\n" + fogText
        val builder = AlertDialog.Builder(this)
            .setTitle(day.date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", uk)))
            .setMessage(description)
            .setNegativeButton("Закрити", null)
        if (hasHourlyForecast) builder.setPositiveButton("По годинах") { _, _ ->
            val intent = Intent(this, HourlyDetailActivity::class.java)
            intent.putExtra("target_date", day.date.toString())
            startActivity(intent)
        }
        builder.show()
    }

    private fun updateSunProgress() {
        val f = lastForecast ?: return
        val rising = f.sunrise ?: return
        val setting = f.sunset ?: return
        sunrise.text = "☀ Схід ${rising.format(DateTimeFormatter.ofPattern("HH:mm"))}"
        sunset.text = "Захід ${setting.format(DateTimeFormatter.ofPattern("HH:mm"))} ☀"
        val minutes = ChronoUnit.MINUTES.between(rising, setting).coerceAtLeast(1)
        val now = f.currentTime.plusSeconds(((SystemClock.elapsedRealtime() - sunFetchTime)/1000).coerceAtLeast(0))
        val elapsed = ChronoUnit.MINUTES.between(rising, now)
        sunProgress.progress = (1000.0 * elapsed / minutes).roundToInt().coerceIn(0, 1000)
        dayLength.text = "Тривалість дня ${minutes / 60} год ${minutes % 60} хв"
        sunNow.text = "Зараз ${now.format(DateTimeFormatter.ofPattern("HH:mm"))}"
    }
}
