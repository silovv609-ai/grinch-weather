package com.grinch.weatherwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.concurrent.thread

/** Scrollable forecast: settings gear, pull-to-refresh, 5-day chart, hourly + 14-day details. */
class MainActivity : Activity() {
    private lateinit var cityTitle: TextView
    private lateinit var temperature: TextView
    private lateinit var conditions: TextView
    private lateinit var currentWind: TextView
    private lateinit var status: TextView
    private lateinit var hourlyRows: LinearLayout
    private lateinit var dailyRows: LinearLayout
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var chart: FiveDayChartView
    private lateinit var chartTitle: TextView
    private var displayedCity: String? = null
    private var requestSerial: Int = 0
    private var lastSuccessAt: Long = 0L
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val autoTick = object : Runnable {
        override fun run() {
            if (WidgetRefreshScheduler.isEnabled(this@MainActivity)) {
                loadForecast(force = true)
                scheduleForegroundRefresh()
            }
        }
    }

    private fun scheduleForegroundRefresh() {
        refreshHandler.removeCallbacks(autoTick)
        if (WidgetRefreshScheduler.isEnabled(this)) {
            val delayMs = WidgetRefreshScheduler.intervalHours(this).toLong() * 60L * 60L * 1000L
            refreshHandler.postDelayed(autoTick, delayMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 22, 34)
        window.navigationBarColor = android.graphics.Color.rgb(16, 22, 34)
        setContentView(R.layout.activity_main)

        cityTitle = findViewById(R.id.mainCity)
        temperature = findViewById(R.id.mainTemp)
        conditions = findViewById(R.id.mainCondition)
        currentWind = findViewById(R.id.mainWind)
        status = findViewById(R.id.mainStatus)
        hourlyRows = findViewById(R.id.hourlyRows)
        dailyRows = findViewById(R.id.dailyRows)
        chart = findViewById(R.id.fiveDayChart)
        chartTitle = findViewById(R.id.chartTitle)
        swipe = findViewById(R.id.pullToRefresh)
        swipe.setColorSchemeColors(android.graphics.Color.rgb(143, 211, 255))
        swipe.setProgressBackgroundColorSchemeColor(android.graphics.Color.rgb(32, 45, 64))
        swipe.setOnRefreshListener { loadForecast(force = true) }

        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }
        WidgetRefreshScheduler.ensureScheduled(this)
    }

    override fun onResume() {
        super.onResume()
        val expiryMs = WidgetRefreshScheduler.intervalHours(this).toLong() * 60L * 60L * 1000L
        val isStale = WidgetRefreshScheduler.isEnabled(this) &&
            lastSuccessAt != 0L && SystemClock.elapsedRealtime() - lastSuccessAt >= expiryMs
        loadForecast(force = isStale)
        scheduleForegroundRefresh()
    }

    override fun onPause() {
        refreshHandler.removeCallbacks(autoTick)
        super.onPause()
    }

    private fun chosenCity(): String? {
        // Settings update the default city for both this screen and all widgets.
        val prefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        return prefs.getString("default_city", null)
    }

    private fun loadForecast(force: Boolean) {
        val city = chosenCity()
        if (city.isNullOrBlank()) {
            displayedCity = null
            cityTitle.text = "Оберіть місто"
            status.text = "Натисни ⚙, щоб вибрати місто."
            swipe.isRefreshing = false
            return
        }
        if (!force && city == displayedCity) return
        val changedCity = city != displayedCity
        displayedCity = city
        cityTitle.text = city
        status.text = "Оновлюємо прогноз…"
        if (force) swipe.isRefreshing = true
        if (changedCity) {
            hourlyRows.removeAllViews()
            dailyRows.removeAllViews()
            chart.visibility = View.GONE
            chartTitle.visibility = View.GONE
        }
        val requestId = ++requestSerial

        thread(name = "GrinchWeatherForecast") {
            try {
                val result = WeatherApi.fetch(city)
                runOnUiThread {
                    if (requestId != requestSerial || isFinishing || isDestroyed) return@runOnUiThread
                    renderForecast(result)
                    lastSuccessAt = SystemClock.elapsedRealtime()
                    swipe.isRefreshing = false
                    // Update the widget too, independent of automatic-update interval.
                    WidgetRefreshScheduler.refreshNow(this)
                }
            } catch (error: Exception) {
                android.util.Log.e("GrinchWeather", "Forecast loading failed", error)
                runOnUiThread {
                    if (requestId != requestSerial || isFinishing || isDestroyed) return@runOnUiThread
                    swipe.isRefreshing = false
                    status.text = "Не вдалося оновити: ${error.message ?: "перевір інтернет"}. Потягни вниз ще раз."
                }
            }
        }
    }

    private fun renderForecast(forecast: WeatherApi.Forecast) {
        cityTitle.text = forecast.city
        temperature.text = "${forecast.temperature}° ${forecast.icon}"
        conditions.text = "${forecast.description} · відчувається ${forecast.feelsLike}°"
        currentWind.text = "Вітер ${WeatherApi.speed(forecast.wind)} м/с ${WeatherApi.arrow(forecast.windDegrees)}"
        status.text = "Потягни вниз для оновлення · Open-Meteo"

        chart.setForecast(forecast.days.take(5))
        chart.visibility = if (forecast.days.isEmpty()) View.GONE else View.VISIBLE
        chartTitle.visibility = chart.visibility

        val hourFormat = DateTimeFormatter.ofPattern("HH:mm")
        hourlyRows.removeAllViews()
        if (forecast.hours.isEmpty()) {
            addRow(hourlyRows, "Погодинний прогноз тимчасово недоступний.")
        } else {
            for (hour in forecast.hours) {
                val nextDay = if (hour.time.toLocalDate() != forecast.hours.first().time.toLocalDate()) " +1д" else ""
                addRow(hourlyRows,
                    "${hour.time.format(hourFormat)}$nextDay    ${hour.temp}°    " +
                    "${WeatherApi.arrow(hour.degrees)} ${WeatherApi.speed(hour.wind)} м/с")
            }
        }

        val dayFormat = DateTimeFormatter.ofPattern("dd.MM", Locale("uk", "UA"))
        dailyRows.removeAllViews()
        if (forecast.days.isEmpty()) {
            addRow(dailyRows, "Прогноз на 14 днів тимчасово недоступний.")
        } else {
            for (day in forecast.days) {
                val icon = WeatherApi.condition(day.code).second
                addRow(dailyRows,
                    "${day.date.format(dayFormat)}  $icon   ${day.min}…${day.max}°\n" +
                    "Вітер ${WeatherApi.arrow(day.degrees)} ${WeatherApi.speed(day.wind)} м/с  ·  Опади ${day.rain}%")
            }
        }
    }

    private fun addRow(container: LinearLayout, content: String) {
        val density = resources.displayMetrics.density
        val row = TextView(this).apply {
            text = content
            setTextColor(android.graphics.Color.rgb(227, 236, 249))
            textSize = 15f
            setPadding((12 * density).toInt(), (11 * density).toInt(),
                (10 * density).toInt(), (11 * density).toInt())
            setBackgroundColor(android.graphics.Color.rgb(31, 43, 62))
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = (3 * density).toInt() }
        container.addView(row, params)
    }
}
