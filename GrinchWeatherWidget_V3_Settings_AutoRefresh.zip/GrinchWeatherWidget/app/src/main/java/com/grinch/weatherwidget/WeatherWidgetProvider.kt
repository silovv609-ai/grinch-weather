package com.grinch.weatherwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WeatherWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            showStartingWidget(context, manager, id)
        }
        WidgetRefreshScheduler.ensureScheduled(context)
        WidgetRefreshScheduler.refreshNow(context)
    }

    override fun onEnabled(context: Context) {
        WidgetRefreshScheduler.ensureScheduled(context)
    }

    override fun onDisabled(context: Context) {
        // No widgets on home screen: avoid unnecessary periodic API requests.
        WidgetRefreshScheduler.stopPeriodic(context)
    }

    companion object {
        private fun openForecast(context: Context, widgetId: Int): PendingIntent {
            val intent = Intent(context, MainActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context, widgetId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun showStartingWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            val city = prefs.getString("city_$id", prefs.getString("default_city", null))
            val views = RemoteViews(context.packageName, R.layout.widget_weather)
            views.setOnClickPendingIntent(R.id.widgetRoot, openForecast(context, id))
            views.setTextViewText(R.id.cityText, city ?: "Оберіть місто")
            views.setTextViewText(R.id.conditionText, if (city.isNullOrBlank())
                "Натисни для вибору міста" else "Оновлюємо погоду…")
            views.setTextViewText(R.id.detailsText, "Вітер — м/с")
            views.setTextViewText(R.id.tempText, "--°")
            views.setTextViewText(R.id.iconText, "☾")
            manager.updateAppWidget(id, views)
        }

        // Called after city settings change or a launcher widget update.
        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            showStartingWidget(context, manager, widgetId)
            WidgetRefreshScheduler.refreshNow(context)
        }

        // Runs inside a WorkManager Worker, not on the UI/broadcast receiver thread.
        fun updateWidgetBlocking(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            val city = prefs.getString("city_$widgetId", prefs.getString("default_city", null))
            if (city.isNullOrBlank()) {
                showStartingWidget(context, manager, widgetId)
                return
            }
            try {
                val forecast = WeatherApi.fetch(city)
                val views = RemoteViews(context.packageName, R.layout.widget_weather)
                views.setOnClickPendingIntent(R.id.widgetRoot, openForecast(context, widgetId))
                views.setTextViewText(R.id.cityText, forecast.city)
                views.setTextViewText(R.id.tempText, "${forecast.temperature}°")
                views.setTextViewText(R.id.iconText, forecast.icon)
                views.setTextViewText(R.id.conditionText, forecast.description)
                views.setTextViewText(
                    R.id.detailsText,
                    "Вітер ${WeatherApi.speed(forecast.wind)} м/с ${WeatherApi.arrow(forecast.windDegrees)}" +
                        "   ·   Відчувається ${forecast.feelsLike}°"
                )
                manager.updateAppWidget(widgetId, views)
            } catch (error: Exception) {
                android.util.Log.e("GrinchWeather", "Widget refresh failed", error)
                // Keep the last successful reading displayed when the network is temporarily down.
                val views = RemoteViews(context.packageName, R.layout.widget_weather)
                views.setOnClickPendingIntent(R.id.widgetRoot, openForecast(context, widgetId))
                views.setTextViewText(R.id.cityText, city)
                views.setTextViewText(R.id.conditionText, "Не вдалося оновити. Відкрий прогноз")
                manager.partiallyUpdateAppWidget(widgetId, views)
            }
        }
    }
}
