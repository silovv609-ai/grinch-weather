package com.grinch.weatherwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.NumberPicker
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Manual city and widget auto-refresh settings. */
class ConfigActivity : Activity() {
    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        window.statusBarColor = android.graphics.Color.rgb(16, 22, 34)
        window.navigationBarColor = android.graphics.Color.rgb(16, 22, 34)
        setContentView(R.layout.activity_config)

        widgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        )
        val prefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        val savedCity = if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            prefs.getString("default_city", "")
        } else {
            prefs.getString("city_$widgetId", prefs.getString("default_city", ""))
        }
        val input = findViewById<EditText>(R.id.cityInput)
        input.setText(savedCity ?: "")

        val autoSwitch = findViewById<Switch>(R.id.autoRefreshSwitch)
        val intervalPicker = findViewById<NumberPicker>(R.id.intervalPicker)
        val intervalLabel = findViewById<TextView>(R.id.intervalLabel)
        intervalPicker.minValue = 1
        intervalPicker.maxValue = 24
        intervalPicker.wrapSelectorWheel = false
        intervalPicker.value = WidgetRefreshScheduler.intervalHours(this)
        autoSwitch.isChecked = WidgetRefreshScheduler.isEnabled(this)

        fun updateIntervalUi() {
            intervalPicker.isEnabled = autoSwitch.isChecked
            intervalPicker.alpha = if (autoSwitch.isChecked) 1.0f else 0.4f
            val hours = intervalPicker.value
            intervalLabel.text = if (autoSwitch.isChecked) {
                "Оновлювати кожні $hours ${hourWord(hours)}"
            } else {
                "Автоматичне оновлення вимкнено"
            }
        }
        autoSwitch.setOnCheckedChangeListener { _, _ -> updateIntervalUi() }
        intervalPicker.setOnValueChangedListener { _, _, _ -> updateIntervalUi() }
        updateIntervalUi()

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val city = input.text.toString().trim()
            if (city.isEmpty()) {
                Toast.makeText(this, "Введи назву міста", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            prefs.edit().putString("default_city", city).apply()
            WidgetRefreshScheduler.saveSettings(this, autoSwitch.isChecked, intervalPicker.value)

            val manager = AppWidgetManager.getInstance(this)
            val ids = manager.getAppWidgetIds(ComponentName(this, WeatherWidgetProvider::class.java))
            // One city shared across all widgets when changed in settings.
            prefs.edit().apply {
                ids.forEach { putString("city_$it", city) }
            }.apply()

            if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                prefs.edit().putString("city_$widgetId", city).apply()
                val result = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                setResult(RESULT_OK, result)
            } else {
                setResult(RESULT_OK)
            }

            WidgetRefreshScheduler.refreshNow(this)
            Toast.makeText(this, "Налаштування збережено", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun hourWord(hours: Int): String {
        return if (hours % 10 == 1 && hours % 100 != 11) "годину"
        else if (hours % 10 in 2..4 && hours % 100 !in 12..14) "години"
        else "годин"
    }
}
