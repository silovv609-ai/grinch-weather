package com.grinch.weatherwidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/** Five-column forecast chart with high/low temperature lines and simple monochrome icons. */
class FiveDayChartView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var days: List<WeatherApi.Day> = emptyList()
    private val density = resources.displayMetrics.density
    private val sp = resources.displayMetrics.scaledDensity
    private val dayFormat = DateTimeFormatter.ofPattern("EE", Locale("uk", "UA"))
    private val dateFormat = DateTimeFormatter.ofPattern("dd.MM")

    fun setForecast(value: List<WeatherApi.Day>) {
        days = value.take(5)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (days.isEmpty()) return
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = 12f * density
        val col = (w - 2f * pad) / days.size
        val xs = days.indices.map { pad + col * (it + 0.5f) }
        val text = Color.rgb(231, 238, 249)
        val muted = Color.rgb(174, 195, 218)

        days.forEachIndexed { i, day ->
            drawText(canvas, day.date.format(dayFormat).replaceFirstChar { it.uppercase() },
                xs[i], 23f * density, 11.5f * sp, text, true)
            drawText(canvas, day.date.format(dateFormat),
                xs[i], 40f * density, 10f * sp, muted, false)
            drawIcon(canvas, xs[i], 66f * density, day.code)
        }

        val allTemps = days.flatMap { listOf(it.min, it.max) }
        val low = allTemps.minOrNull() ?: 0
        val high = allTemps.maxOrNull() ?: 1
        val spread = (high - low).coerceAtLeast(3)
        val top = 100f * density
        val bottom = (h - 78f * density).coerceAtLeast(top + 40f * density)
        fun y(value: Int): Float = bottom - (value - low).toFloat() / spread * (bottom - top)

        fun trace(values: List<Int>, color: Int, labelAbove: Boolean) {
            paint.color = color
            paint.strokeWidth = 1.8f * density
            paint.style = Paint.Style.STROKE
            val path = Path()
            values.forEachIndexed { i, v ->
                if (i == 0) path.moveTo(xs[i], y(v)) else path.lineTo(xs[i], y(v))
            }
            canvas.drawPath(path, paint)
            paint.style = Paint.Style.FILL
            values.forEachIndexed { i, v ->
                canvas.drawCircle(xs[i], y(v), 2.8f * density, paint)
                val labelY = if (labelAbove) y(v) - 9f * density else y(v) + 17f * density
                drawText(canvas, "$v°", xs[i], labelY, 11.5f * sp, text, true)
            }
        }
        trace(days.map { it.max }, Color.rgb(225, 182, 105), true)
        trace(days.map { it.min }, Color.rgb(122, 190, 169), false)

        val bottomText = h - 21f * density
        days.forEachIndexed { i, day ->
            drawText(canvas, WeatherApi.arrow(day.degrees), xs[i], bottomText - 17f * density,
                13f * sp, muted, true)
            drawText(canvas, "${WeatherApi.speed(day.wind)}", xs[i], bottomText,
                10.5f * sp, text, false)
        }
        drawText(canvas, "вітер, м/с", w / 2f, h - 5f * density,
            9.5f * sp, muted, false)
    }

    private fun drawText(canvas: Canvas, text: String, x: Float, y: Float,
                         size: Float, color: Int, bold: Boolean) {
        paint.apply {
            this.color = color
            textSize = size
            isFakeBoldText = bold
            textAlign = Paint.Align.CENTER
            style = Paint.Style.FILL
        }
        canvas.drawText(text, x, y, paint)
    }

    private fun drawIcon(canvas: Canvas, x: Float, y: Float, code: Int) {
        val white = Color.rgb(229, 236, 247)
        val size = 0.85f * density
        val sunny = code == 0 || code == 1
        val cloudy = code in 2..3 || code in 45..48
        if (sunny || code == 2) {
            paint.style = Paint.Style.STROKE
            paint.color = white
            paint.strokeWidth = 1.6f * density
            canvas.drawCircle(x, y - 3f * density, 7f * size, paint)
            for (i in 0 until 8) {
                val a = Math.PI * i / 4.0
                val sx = x + (10f * size * cos(a)).toFloat()
                val sy = y - 3f * density + (10f * size * sin(a)).toFloat()
                val ex = x + (13f * size * cos(a)).toFloat()
                val ey = y - 3f * density + (13f * size * sin(a)).toFloat()
                canvas.drawLine(sx, sy, ex, ey, paint)
            }
        }
        if (!sunny || cloudy) {
            paint.color = white
            paint.style = Paint.Style.FILL
            val cloudX = if (code == 2) x + 5f * size else x
            canvas.drawRoundRect(RectF(cloudX - 12f * size, y - 3f * size,
                cloudX + 12f * size, y + 6f * size), 5f * size, 5f * size, paint)
            canvas.drawCircle(cloudX - 4f * size, y - 4f * size, 7f * size, paint)
            canvas.drawCircle(cloudX + 4f * size, y - 6f * size, 8f * size, paint)
        }
        if (code in listOf(51,53,55,56,57,61,63,65,66,67,80,81,82,95,96,99)) {
            paint.color = Color.rgb(143, 211, 255)
            paint.strokeWidth = 1.6f * density
            paint.style = Paint.Style.STROKE
            for (i in -1..1) {
                val xx = x + i * 7f * size
                canvas.drawLine(xx, y + 10f * size, xx - 3f * size, y + 15f * size, paint)
            }
        }
        if (code in listOf(71,73,75,77,85,86)) {
            paint.color = white
            paint.style = Paint.Style.FILL
            for (i in -1..1) canvas.drawCircle(x + i * 7f * size, y + 12f * size, 2f * size, paint)
        }
        paint.style = Paint.Style.FILL
    }
}
