package com.grinch.weatherwidget

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.Locale
import kotlin.math.roundToInt

/** Shared forecast loader for the Android widget and the full-screen activity. */
object WeatherApi {
    data class Hour(
        val time: LocalDateTime,
        val temp: Int,
        val wind: Double,
        val degrees: Double,
        val code: Int
    )

    data class Day(
        val date: LocalDate,
        val min: Int,
        val max: Int,
        val wind: Double,
        val degrees: Double,
        val rain: Int,
        val code: Int
    )

    data class Forecast(
        val city: String,
        val temperature: Int,
        val feelsLike: Int,
        val wind: Double,
        val windDegrees: Double,
        val description: String,
        val icon: String,
        val hours: List<Hour>,
        val days: List<Day>
    )

    fun fetch(city: String): Forecast {
        require(city.isNotBlank()) { "Спочатку вибери місто" }
        val geocodeUrl = "https://geocoding-api.open-meteo.com/v1/search" +
            "?name=${URLEncoder.encode(city, "UTF-8")}&count=1&language=uk&format=json"
        val places = JSONObject(readUrl(geocodeUrl)).optJSONArray("results")
        if (places == null || places.length() == 0) {
            throw IllegalArgumentException("Місто не знайдено. Перевір його назву.")
        }
        val place = places.getJSONObject(0)
        val lat = place.getDouble("latitude")
        val lon = place.getDouble("longitude")
        val actualCity = place.optString("name", city)

        val forecastUrl = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m" +
            "&hourly=temperature_2m,weather_code,wind_speed_10m,wind_direction_10m" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,wind_direction_10m_dominant,weather_code" +
            "&wind_speed_unit=ms&forecast_days=14&timezone=auto"

        val root = JSONObject(readUrl(forecastUrl))
        val current = root.getJSONObject("current")
        val currentTime = LocalDateTime.parse(current.getString("time"))
        val currentCode = current.getInt("weather_code")
        val (description, icon) = condition(currentCode, current.optInt("is_day", 1) == 1)

        val hourly = root.getJSONObject("hourly")
        val times = hourly.getJSONArray("time")
        val temperatures = hourly.getJSONArray("temperature_2m")
        val winds = hourly.getJSONArray("wind_speed_10m")
        val directions = hourly.getJSONArray("wind_direction_10m")
        val codes = hourly.getJSONArray("weather_code")
        val hours = mutableListOf<Hour>()
        for (i in 0 until times.length()) {
            val time = LocalDateTime.parse(times.getString(i))
            if (time.isBefore(currentTime)) continue
            hours.add(
                Hour(
                    time,
                    temperatures.getDouble(i).roundToInt(),
                    winds.getDouble(i),
                    directions.getDouble(i),
                    codes.getInt(i)
                )
            )
            if (hours.size == 24) break
        }

        val daily = root.getJSONObject("daily")
        val dates = daily.getJSONArray("time")
        val minTemps = daily.getJSONArray("temperature_2m_min")
        val maxTemps = daily.getJSONArray("temperature_2m_max")
        val maxWinds = daily.getJSONArray("wind_speed_10m_max")
        val mainDirections = daily.getJSONArray("wind_direction_10m_dominant")
        val rain = daily.getJSONArray("precipitation_probability_max")
        val dailyCodes = daily.getJSONArray("weather_code")
        val days = mutableListOf<Day>()
        for (i in 0 until dates.length()) {
            days.add(
                Day(
                    LocalDate.parse(dates.getString(i)),
                    minTemps.getDouble(i).roundToInt(),
                    maxTemps.getDouble(i).roundToInt(),
                    maxWinds.getDouble(i),
                    mainDirections.getDouble(i),
                    rain.optInt(i, 0),
                    dailyCodes.getInt(i)
                )
            )
        }

        return Forecast(
            actualCity,
            current.getDouble("temperature_2m").roundToInt(),
            current.getDouble("apparent_temperature").roundToInt(),
            current.getDouble("wind_speed_10m"),
            current.getDouble("wind_direction_10m"),
            description,
            icon,
            hours,
            days
        )
    }

    fun speed(value: Double): String = String.format(Locale.US, "%.1f", value)

    // Open-Meteo reports where the wind COMES FROM; the arrow shows where it BLOWS TO.
    fun arrow(fromDegrees: Double): String {
        val arrows = arrayOf("↑", "↗", "→", "↘", "↓", "↙", "←", "↖")
        val directionTo = (((fromDegrees + 180.0) % 360.0) + 360.0) % 360.0
        val index = ((directionTo + 22.5) / 45.0).toInt() % 8
        return arrows[index]
    }

    fun condition(code: Int, isDay: Boolean = true): Pair<String, String> = when (code) {
        0 -> "Ясно" to if (isDay) "☀" else "☾"
        1 -> "Переважно ясно" to if (isDay) "🌤" else "☾"
        2 -> "Мінлива хмарність" to "⛅"
        3 -> "Хмарно" to "☁"
        45, 48 -> "Туман" to "🌫"
        51, 53, 55, 56, 57 -> "Мряка" to "🌦"
        61, 63, 65, 66, 67 -> "Дощ" to "🌧"
        71, 73, 75, 77 -> "Сніг" to "❄"
        80, 81, 82 -> "Зливи" to "🌧"
        85, 86 -> "Снігопад" to "🌨"
        95, 96, 99 -> "Гроза" to "⛈"
        else -> "Погода" to "🌡"
    }

    private fun readUrl(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 12000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Сервер погоди повернув ${connection.responseCode}")
            }
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
