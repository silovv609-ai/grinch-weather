package com.grinch.weatherwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlin.concurrent.thread

class WeatherWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, manager, it) }
    }

    companion object {
        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            val city = prefs.getString("city_$widgetId", prefs.getString("default_city", null))
            val views = RemoteViews(context.packageName, R.layout.widget_weather)
            val openApp = Intent(context, MainActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(
                context,
                widgetId,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pending)
            views.setTextViewText(R.id.cityText, city ?: "Оберіть місто")
            views.setTextViewText(R.id.conditionText, if (city.isNullOrBlank()) "Натисни, щоб вибрати місто" else "Оновлюємо погоду…")
            views.setTextViewText(R.id.detailsText, "Вітер — м/с")
            views.setTextViewText(R.id.tempText, "--°")
            views.setTextViewText(R.id.iconText, "☾")
            manager.updateAppWidget(widgetId, views)
            if (city.isNullOrBlank()) return

            // Fetch off the main thread. Widget updates are independent of the full-screen screen.
            thread(name = "GrinchWidget-$widgetId") {
                try {
                    val forecast = WeatherApi.fetch(city)
                    val ready = RemoteViews(context.packageName, R.layout.widget_weather)
                    ready.setOnClickPendingIntent(R.id.widgetRoot, pending)
                    ready.setTextViewText(R.id.cityText, forecast.city)
                    ready.setTextViewText(R.id.tempText, "${forecast.temperature}°")
                    ready.setTextViewText(R.id.iconText, forecast.icon)
                    ready.setTextViewText(R.id.conditionText, forecast.description)
                    ready.setTextViewText(
                        R.id.detailsText,
                        "Вітер ${WeatherApi.speed(forecast.wind)} м/с ${WeatherApi.arrow(forecast.windDegrees)}" +
                            "   ·   Відчувається ${forecast.feelsLike}°"
                    )
                    manager.updateAppWidget(widgetId, ready)
                } catch (error: Exception) {
                    android.util.Log.e("GrinchWeather", "Widget fetch failed", error)
                    val failed = RemoteViews(context.packageName, R.layout.widget_weather)
                    failed.setOnClickPendingIntent(R.id.widgetRoot, pending)
                    failed.setTextViewText(R.id.cityText, city)
                    failed.setTextViewText(R.id.tempText, "--°")
                    failed.setTextViewText(R.id.conditionText, "Немає даних. Натисни, щоб перевірити")
                    failed.setTextViewText(R.id.detailsText, "Відкрий прогноз або перевір інтернет")
                    manager.updateAppWidget(widgetId, failed)
                }
            }
        }
    }
}
