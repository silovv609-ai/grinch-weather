package com.grinch.weatherwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.concurrent.thread

/** Full-screen scrollable 24-hour wind and 14-day forecast. */
class MainActivity : Activity() {
    private lateinit var cityTitle: TextView
    private lateinit var temperature: TextView
    private lateinit var conditions: TextView
    private lateinit var currentWind: TextView
    private lateinit var status: TextView
    private lateinit var hourlyRows: LinearLayout
    private lateinit var dailyRows: LinearLayout
    private var displayedCity: String? = null
    private var requestSerial: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 22, 34)
        window.navigationBarColor = android.graphics.Color.rgb(16, 22, 34)
        setContentView(R.layout.activity_main)

        cityTitle = findViewById(R.id.mainCity)
        temperature = findViewById(R.id.mainTemp)
        conditions = findViewById(R.id.mainCondition)
        currentWind = findViewById(R.id.mainWind)
        status = findViewById(R.id.mainStatus)
        hourlyRows = findViewById(R.id.hourlyRows)
        dailyRows = findViewById(R.id.dailyRows)

        findViewById<Button>(R.id.changeCityButton).setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }
        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            loadForecast(force = true)
        }
    }

    override fun onResume() {
        super.onResume()
        loadForecast(force = false)
    }

    private fun chosenCity(): String? {
        val prefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        val widgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        )
        return (if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID)
            prefs.getString("city_$widgetId", null) else null)
            ?: prefs.getString("default_city", null)
    }

    private fun loadForecast(force: Boolean) {
        val city = chosenCity()
        if (city.isNullOrBlank()) {
            displayedCity = null
            cityTitle.text = "Оберіть місто"
            status.text = "Натисни «Місто», щоб вибрати місто вручну."
            return
        }
        if (!force && city == displayedCity) return
        displayedCity = city
        cityTitle.text = city
        status.text = "Оновлюємо прогноз…"
        hourlyRows.removeAllViews()
        dailyRows.removeAllViews()
        val requestId = ++requestSerial

        thread(name = "GrinchWeatherForecast") {
            try {
                val result = WeatherApi.fetch(city)
                runOnUiThread {
                    if (requestId != requestSerial || isFinishing || isDestroyed) return@runOnUiThread
                    renderForecast(result)
                    // Keep the home screen widget in sync when the application loads.
                    val manager = AppWidgetManager.getInstance(this)
                    val ids = manager.getAppWidgetIds(
                        ComponentName(this, WeatherWidgetProvider::class.java)
                    )
                    ids.forEach { WeatherWidgetProvider.updateWidget(this, manager, it) }
                }
            } catch (error: Exception) {
                android.util.Log.e("GrinchWeather", "Forecast screen loading failed", error)
                runOnUiThread {
                    if (requestId != requestSerial || isFinishing || isDestroyed) return@runOnUiThread
                    status.text = "Не вдалося завантажити дані: ${error.message ?: "перевір інтернет"}. Натисни «Оновити»."
                }
            }
        }
    }

    private fun renderForecast(forecast: WeatherApi.Forecast) {
        cityTitle.text = forecast.city
        temperature.text = "${forecast.temperature}° ${forecast.icon}"
        conditions.text = "${forecast.description} · відчувається ${forecast.feelsLike}°"
        currentWind.text = "Вітер ${WeatherApi.speed(forecast.wind)} м/с ${WeatherApi.arrow(forecast.windDegrees)}"
        status.text = "Стрілка показує, куди дме вітер. Дані: Open-Meteo."

        val hourFormat = DateTimeFormatter.ofPattern("HH:mm")
        if (forecast.hours.isEmpty()) {
            addRow(hourlyRows, "Погодинний прогноз тимчасово недоступний.")
        } else {
            for (hour in forecast.hours) {
                val nextDay = if (hour.time.toLocalDate() != forecast.hours.first().time.toLocalDate()) " +1д" else ""
                addRow(
                    hourlyRows,
                    "${hour.time.format(hourFormat)}$nextDay    ${hour.temp}°    " +
                        "${WeatherApi.arrow(hour.degrees)} ${WeatherApi.speed(hour.wind)} м/с"
                )
            }
        }

        val dayFormat = DateTimeFormatter.ofPattern("dd.MM", Locale("uk", "UA"))
        if (forecast.days.isEmpty()) {
            addRow(dailyRows, "Прогноз на 14 днів тимчасово недоступний.")
        } else {
            for (day in forecast.days) {
                val icon = WeatherApi.condition(day.code).second
                addRow(
                    dailyRows,
                    "${day.date.format(dayFormat)}  $icon   ${day.min}…${day.max}°\n" +
                        "Вітер ${WeatherApi.arrow(day.degrees)} ${WeatherApi.speed(day.wind)} м/с  ·  Опади ${day.rain}%"
                )
            }
        }
    }

    private fun addRow(container: LinearLayout, content: String) {
        val density = resources.displayMetrics.density
        val row = TextView(this).apply {
            text = content
            setTextColor(android.graphics.Color.rgb(227, 236, 249))
            textSize = 15f
            setPadding(
                (12 * density).toInt(), (11 * density).toInt(),
                (10 * density).toInt(), (11 * density).toInt()
            )
            setBackgroundColor(android.graphics.Color.rgb(31, 43, 62))
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = (3 * density).toInt() }
        container.addView(row, params)
    }
}
