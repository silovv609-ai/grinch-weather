package com.grinch.weatherwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

/** City picker used both during widget installation and from the full forecast screen. */
class ConfigActivity : Activity() {
    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        setContentView(R.layout.activity_config)

        widgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        )
        val prefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        val savedCity = if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            prefs.getString("default_city", "")
        } else {
            prefs.getString("city_$widgetId", prefs.getString("default_city", ""))
        }
        val input = findViewById<EditText>(R.id.cityInput)
        input.setText(savedCity ?: "")

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val city = input.text.toString().trim()
            if (city.isEmpty()) {
                Toast.makeText(this, "Введи назву міста", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val manager = AppWidgetManager.getInstance(this)
            prefs.edit().putString("default_city", city).apply()

            if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
                // City changed inside the app: update the home-screen widgets too.
                val ids = manager.getAppWidgetIds(
                    ComponentName(this, WeatherWidgetProvider::class.java)
                )
                for (id in ids) {
                    prefs.edit().putString("city_$id", city).apply()
                    WeatherWidgetProvider.updateWidget(this, manager, id)
                }
                setResult(RESULT_OK)
            } else {
                // Initial widget configuration: return its ID to the launcher.
                prefs.edit().putString("city_$widgetId", city).apply()
                WeatherWidgetProvider.updateWidget(this, manager, widgetId)
                val result = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                setResult(RESULT_OK, result)
            }
            finish()
        }
    }
}
