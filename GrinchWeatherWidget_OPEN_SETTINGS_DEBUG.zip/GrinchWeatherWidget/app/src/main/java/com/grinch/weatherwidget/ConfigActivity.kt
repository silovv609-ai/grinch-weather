package com.grinch.weatherwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class ConfigActivity : Activity() {
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        setContentView(R.layout.activity_config)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        val input = findViewById<EditText>(R.id.cityInput)
        val prefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        input.setText(prefs.getString("city_$appWidgetId", prefs.getString("default_city", "")))

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val city = input.text.toString().trim()
            if (city.isBlank()) {
                Toast.makeText(this, "Введи назву міста", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.edit().putString("default_city", city).apply()
            val manager = AppWidgetManager.getInstance(this)
            if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
                // Launched from app drawer: update every placed widget.
                val ids = manager.getAppWidgetIds(
                    ComponentName(this, WeatherWidgetProvider::class.java)
                )
                for (id in ids) {
                    prefs.edit().putString("city_$id", city).apply()
                    WeatherWidgetProvider.updateWidget(this, manager, id)
                }
                setResult(RESULT_OK)
            } else {
                prefs.edit().putString("city_$appWidgetId", city).apply()
                WeatherWidgetProvider.updateWidget(this, manager, appWidgetId)
                val result = Intent().putExtra(
                    AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId
                )
                setResult(RESULT_OK, result)
            }
            finish()
        }
    }
}
