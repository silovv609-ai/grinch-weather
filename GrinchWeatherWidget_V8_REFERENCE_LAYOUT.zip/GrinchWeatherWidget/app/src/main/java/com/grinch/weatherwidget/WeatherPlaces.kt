package com.grinch.weatherwidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/** One stored coordinate is shared by the app and all home-screen widgets. */
object WeatherPlaces {
    data class Place(
        val name: String,
        val latitude: Double,
        val longitude: Double,
        val details: String = ""
    ) {
        val title: String get() = if (details.isBlank()) name else "$name · $details"
    }

    private const val PREFS = "weather_prefs"
    private const val NO_COORDS = 9999.0
    private var lastNominatimRequestMs = 0L

    fun isGeoEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getBoolean("geo_enabled", false)

    fun manualCity(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString("default_city", "") ?: ""

    fun current(context: Context): Place? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val isGeo = isGeoEnabled(context)
        val lat = prefs.getFloat(if (isGeo) "geo_lat" else "manual_lat", NO_COORDS.toFloat()).toDouble()
        val lon = prefs.getFloat(if (isGeo) "geo_lon" else "manual_lon", NO_COORDS.toFloat()).toDouble()
        if (lat == NO_COORDS || lon == NO_COORDS || lat !in -90.0..90.0 || lon !in -180.0..180.0) {
            return null
        }
        val name = if (isGeo) "Моя геолокація" else manualCity(context).ifBlank { "Обране місце" }
        return Place(name, lat, lon, if (isGeo) "За координатами телефона" else "")
    }

    /** Save the specific selected result. Future refreshes never need to geocode its name. */
    fun saveManual(context: Context, place: Place) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("geo_enabled", false)
            .putString("default_city", place.name)
            .putFloat("manual_lat", place.latitude.toFloat())
            .putFloat("manual_lon", place.longitude.toFloat())
            .apply()
    }

    fun setGeoEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("geo_enabled", enabled).apply()
    }

    fun saveGeoCoordinates(context: Context, lat: Double, lon: Double) {
        if (lat !in -90.0..90.0 || lon !in -180.0..180.0) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("geo_lat", lat.toFloat())
            .putFloat("geo_lon", lon.toFloat())
            .apply()
    }

    fun samePlace(one: Place?, two: Place?): Boolean = one != null && two != null &&
        one.name == two.name && kotlin.math.abs(one.latitude - two.latitude) < 0.0001 &&
        kotlin.math.abs(one.longitude - two.longitude) < 0.0001

    fun parseCoordinates(query: String): Place? {
        val parts = query.split(',', ';').map { it.trim() }
        if (parts.size != 2) return null
        val lat = parts[0].toDoubleOrNull() ?: return null
        val lon = parts[1].toDoubleOrNull() ?: return null
        if (lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
        return Place("${String.format(Locale.US, "%.4f", lat)}, ${String.format(Locale.US, "%.4f", lon)}", lat, lon, "Координати")
    }

    /** Searches only after the user taps Find/Save; no automated Nominatim autocomplete. */
    fun search(query: String): List<Place> {
        val name = query.trim()
        if (name.isBlank()) return emptyList()
        parseCoordinates(name)?.let { return listOf(it) }
        val found = ArrayList<Place>()
        var lastError: Exception? = null
        val escaped = URLEncoder.encode(name, "UTF-8")
        try {
            val url = "https://geocoding-api.open-meteo.com/v1/search?name=$escaped&count=10&language=uk&format=json"
            val json = JSONObject(read(url))
            val results = json.optJSONArray("results")
            if (results != null) {
                for (i in 0 until results.length()) {
                    val obj = results.getJSONObject(i)
                    val title = obj.optString("name", "").trim()
                    if (title.isBlank()) continue
                    val region = listOf(obj.optString("admin2"), obj.optString("admin1"), obj.optString("country"))
                        .filter { it.isNotBlank() }.distinct().joinToString(", ")
                    found.add(Place(title, obj.getDouble("latitude"), obj.getDouble("longitude"), region))
                }
            }
        } catch (error: Exception) { lastError = error }

        try {
            // OpenStreetMap Nominatim is the fallback for small settlements absent in Open-Meteo.
            // A user-triggered single request, with identifying User-Agent and attribution in UI.
            val url = "https://nominatim.openstreetmap.org/search" +
                "?q=$escaped&format=jsonv2&addressdetails=1&limit=8&accept-language=uk"
            synchronized(this) {
                val now = android.os.SystemClock.elapsedRealtime()
                val toWait = 1100L - (now - lastNominatimRequestMs)
                if (toWait > 0L) Thread.sleep(toWait)
                lastNominatimRequestMs = android.os.SystemClock.elapsedRealtime()
            }
            val json = JSONArray(read(url, true))
            for (i in 0 until json.length()) {
                val result = json.getJSONObject(i)
                val addr = result.optJSONObject("address")
                val title = addr?.optString("village")?.takeIf { it.isNotBlank() }
                    ?: addr?.optString("town")?.takeIf { it.isNotBlank() }
                    ?: addr?.optString("city")?.takeIf { it.isNotBlank() }
                    ?: addr?.optString("hamlet")?.takeIf { it.isNotBlank() }
                    ?: result.optString("name").takeIf { it.isNotBlank() }
                    ?: result.optString("display_name").substringBefore(',')
                val detail = result.optString("display_name").split(',').drop(1)
                    .take(3).joinToString(", ").trim()
                found.add(Place(title, result.getString("lat").toDouble(),
                    result.getString("lon").toDouble(), detail))
            }
        } catch (error: Exception) { lastError = error }

        val unique = ArrayList<Place>()
        for (candidate in found) {
            if (unique.none {
                    kotlin.math.abs(it.latitude - candidate.latitude) < .007 &&
                    kotlin.math.abs(it.longitude - candidate.longitude) < .007
                }) unique.add(candidate)
        }
        if (unique.isEmpty() && lastError != null) {
            throw IllegalStateException("Не вдалося знайти населений пункт. Перевір інтернет або введи координати.", lastError)
        }
        return unique.take(14)
    }

    private fun read(address: String, osm: Boolean = false): String {
        val c = URL(address).openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 12000
        c.readTimeout = 12000
        c.setRequestProperty("Accept", "application/json")
        if (osm) {
            c.setRequestProperty("User-Agent", "GrinchWeather/5.0 (https://github.com/silovv609-ai/grinch-weather)")
            c.setRequestProperty("Referer", "https://github.com/silovv609-ai/grinch-weather")
        }
        return try {
            if (c.responseCode !in 200..299) throw IllegalStateException("Помилка пошуку: ${c.responseCode}")
            c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }
}
