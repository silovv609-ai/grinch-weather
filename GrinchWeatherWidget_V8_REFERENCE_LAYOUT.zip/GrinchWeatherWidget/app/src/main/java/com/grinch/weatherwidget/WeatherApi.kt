package com.grinch.weatherwidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.Locale
import kotlin.math.roundToInt

/** Forecast is always requested by saved coordinates; never geocode a saved place on every refresh. */
object WeatherApi {
    data class Hour(
        val time: LocalDateTime,
        val temp: Int,
        val wind: Double,
        val degrees: Double,
        val gust: Double,
        val precipitation: Double,
        val rainChance: Int,
        val code: Int,
        val isDay: Boolean
    )

    data class Day(
        val date: LocalDate,
        val min: Int,
        val max: Int,
        val wind: Double,
        val degrees: Double,
        val rain: Int,
        val precipitation: Double,
        val code: Int,
        val fogRisk: Int,
        val gust: Double = 0.0
    )

    data class Forecast(
        val city: String,
        val temperature: Int,
        val feelsLike: Int,
        val wind: Double,
        val windDegrees: Double,
        val precipitation: Double,
        val description: String,
        val icon: String,
        val code: Int,
        val isDay: Boolean,
        val currentTime: LocalDateTime,
        val hours: List<Hour>,
        val days: List<Day>,
        val cached: Boolean = false,
        val sunrise: LocalDateTime? = null,
        val sunset: LocalDateTime? = null
    )

    fun fetch(context: Context): Forecast {
        var place = WeatherPlaces.current(context)
        if (place == null && !WeatherPlaces.isGeoEnabled(context)) {
            // Migration from the old V4 app: resolve its previous city only once.
            val previousCity = WeatherPlaces.manualCity(context)
            if (previousCity.isNotBlank()) {
                place = WeatherPlaces.search(previousCity).firstOrNull()
                if (place == null) throw IllegalArgumentException(
                    "Не знайдено «$previousCity». Відкрий ⚙ і вибери його зі списку або за координатами."
                )
                WeatherPlaces.saveManual(context, place)
            }
        }
        if (place == null) {
            throw IllegalArgumentException("Вибери населений пункт або увімкни геолокацію в ⚙")
        }
        val prefs = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        val key = "${place.latitude},${place.longitude}"
        var cached = false
        val payload = try {
            val json = request(place)
            prefs.edit().putString("forecast_cache_key", key)
                .putString("forecast_cache_json", json)
                .putLong("forecast_cached_at", System.currentTimeMillis())
                .apply()
            json
        } catch (error: Exception) {
            val previous = prefs.getString("forecast_cache_json", null)
            if (prefs.getString("forecast_cache_key", null) != key || previous.isNullOrBlank()) {
                throw error
            }
            cached = true
            previous
        }
        return parseForecast(JSONObject(payload), place.name, cached)
    }

    private fun request(place: WeatherPlaces.Place): String {
        val url = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=${place.latitude}&longitude=${place.longitude}" +
            "&current=temperature_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m,precipitation" +
            "&hourly=temperature_2m,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,precipitation,precipitation_probability,is_day,relative_humidity_2m,visibility" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,wind_speed_10m_max,wind_direction_10m_dominant,wind_gusts_10m_max,weather_code,sunrise,sunset" +
            "&wind_speed_unit=ms&precipitation_unit=mm&forecast_days=14&timezone=auto"
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 14000
        connection.readTimeout = 14000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            if (connection.responseCode !in 200..299) {
                val brief = connection.errorStream?.bufferedReader()?.use { it.readText() }
                    ?.take(160) ?: ""
                throw IllegalStateException("Сервер погоди: ${connection.responseCode} $brief")
            }
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { connection.disconnect() }
    }

    /** A visibility/humidity-based indicative risk index, NOT a calibrated probability forecast. */
    private fun fogIndex(code: Int, humidity: Double?, visibility: Double?): Int {
        if (code == 45 || code == 48) return 95
        val rh = humidity ?: return 0
        val vis = visibility ?: 100000.0
        return when {
            vis < 500 && rh >= 90 -> 90
            vis < 1000 && rh >= 88 -> 80
            vis < 2000 && rh >= 88 -> 70
            vis < 4000 && rh >= 90 -> 60
            rh >= 97 && vis < 12000 -> 50
            rh >= 94 && vis < 15000 -> 35
            rh >= 90 && vis < 20000 -> 20
            else -> 5
        }
    }

    private fun nullableDouble(array: JSONArray?, index: Int): Double? {
        if (array == null || array.isNull(index)) return null
        val number = array.optDouble(index, Double.NaN)
        return number.takeUnless { it.isNaN() || it.isInfinite() }
    }

    private fun parseForecast(root: JSONObject, placeName: String, cached: Boolean): Forecast {
        val current = root.getJSONObject("current")
        val currentTime = LocalDateTime.parse(current.getString("time"))
        val weatherCode = current.getInt("weather_code")
        val isDay = current.optInt("is_day", 1) == 1
        val (description, glyph) = condition(weatherCode, isDay)
        val hourly = root.getJSONObject("hourly")
        val timestamps = hourly.getJSONArray("time")
        val temps = hourly.getJSONArray("temperature_2m")
        val winds = hourly.getJSONArray("wind_speed_10m")
        val directions = hourly.getJSONArray("wind_direction_10m")
        val gusts = hourly.getJSONArray("wind_gusts_10m")
        val precipitation = hourly.getJSONArray("precipitation")
        val rainChances = hourly.getJSONArray("precipitation_probability")
        val codes = hourly.getJSONArray("weather_code")
        val daytime = hourly.getJSONArray("is_day")
        val humidity = hourly.optJSONArray("relative_humidity_2m")
        val visibility = hourly.optJSONArray("visibility")
        val firstDate = currentTime.toLocalDate()
        val hours = ArrayList<Hour>()
        val fogByDate = mutableMapOf<LocalDate, Int>()
        for (i in 0 until timestamps.length()) {
            val time = LocalDateTime.parse(timestamps.getString(i))
            val code = codes.getInt(i)
            val risk = fogIndex(code, nullableDouble(humidity, i), nullableDouble(visibility, i))
            val date = time.toLocalDate()
            fogByDate[date] = maxOf(fogByDate[date] ?: 0, risk)
            if (!date.isBefore(firstDate) && date.isBefore(firstDate.plusDays(7))) {
                hours.add(Hour(time, temps.getDouble(i).roundToInt(), winds.getDouble(i),
                    directions.getDouble(i), gusts.optDouble(i, 0.0),
                    precipitation.optDouble(i, 0.0), rainChances.optInt(i, 0),
                    code, daytime.optInt(i, 1) == 1))
            }
        }
        val daily = root.getJSONObject("daily")
        val days = ArrayList<Day>()
        val dates = daily.getJSONArray("time")
        val lows = daily.getJSONArray("temperature_2m_min")
        val highs = daily.getJSONArray("temperature_2m_max")
        val maxWinds = daily.getJSONArray("wind_speed_10m_max")
        val directionsDaily = daily.getJSONArray("wind_direction_10m_dominant")
        val precipitationProbability = daily.getJSONArray("precipitation_probability_max")
        val precipTotal = daily.getJSONArray("precipitation_sum")
        val dailyCodes = daily.getJSONArray("weather_code")
        val dailyGusts = daily.optJSONArray("wind_gusts_10m_max")
        val sunriseTime = daily.optJSONArray("sunrise")?.optString(0)?.let {
            runCatching { LocalDateTime.parse(it) }.getOrNull()
        }
        val sunsetTime = daily.optJSONArray("sunset")?.optString(0)?.let {
            runCatching { LocalDateTime.parse(it) }.getOrNull()
        }
        for (i in 0 until minOf(dates.length(), 14)) {
            val date = LocalDate.parse(dates.getString(i))
            days.add(Day(date, lows.getDouble(i).roundToInt(), highs.getDouble(i).roundToInt(),
                maxWinds.getDouble(i), directionsDaily.getDouble(i),
                precipitationProbability.optInt(i, 0), precipTotal.optDouble(i, 0.0),
                dailyCodes.getInt(i), fogByDate[date] ?: 0,
                dailyGusts?.optDouble(i, 0.0) ?: 0.0))
        }
        return Forecast(placeName, current.getDouble("temperature_2m").roundToInt(),
            current.getDouble("apparent_temperature").roundToInt(), current.getDouble("wind_speed_10m"),
            current.getDouble("wind_direction_10m"), current.optDouble("precipitation", 0.0),
            description, glyph, weatherCode, isDay, currentTime, hours, days, cached,
            sunriseTime, sunsetTime)
    }

    fun speed(value: Double): String = String.format(Locale.US, "%.1f", value)
    fun mm(value: Double): String = String.format(Locale.US, "%.1f", value)

    /** Arrow points towards the direction where the wind BLOWS, not where it comes from. */
    fun arrow(fromDegrees: Double): String {
        val arrows = arrayOf("↑", "↗", "→", "↘", "↓", "↙", "←", "↖")
        val towards = (((fromDegrees + 180.0) % 360.0) + 360.0) % 360.0
        return arrows[((towards + 22.5) / 45.0).toInt() % 8]
    }

    fun condition(code: Int, isDay: Boolean = true): Pair<String, String> = when (code) {
        0 -> "Ясно" to if (isDay) "☀" else "☾"
        1 -> "Переважно ясно" to if (isDay) "🌤" else "☾"
        2 -> "Мінлива хмарність" to "⛅"
        3 -> "Хмарно" to "☁"
        45, 48 -> "Туман" to "🌫"
        51, 53, 55, 56, 57 -> "Мряка" to "🌦"
        61, 63, 65, 66, 67 -> "Дощ" to "🌧"
        71, 73, 75, 77 -> "Сніг" to "❄"
        80, 81, 82 -> "Зливи" to "🌧"
        85, 86 -> "Снігопад" to "🌨"
        95, 96, 99 -> "Гроза" to "⛈"
        else -> "Погода" to "☁"
    }
}
