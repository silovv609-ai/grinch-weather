package com.grinch.weatherwidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Self-drawn monochrome icon set. No third-party imagery or font downloads. */
class WeatherIconView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private var weatherCode = 3
    private var daytime = true
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setWeather(code: Int, isDay: Boolean = true) {
        weatherCode = code
        daytime = isDay
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        WeatherGlyph.draw(
            canvas, width / 2f, height / 2f,
            minOf(width, height) * 0.68f, weatherCode, daytime, iconPaint
        )
    }
}

internal object WeatherGlyph {
    private val snowCodes = setOf(71, 73, 75, 77, 85, 86)
    private val rainCodes = setOf(51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82)

    fun draw(canvas: Canvas, centerX: Float, centerY: Float, radius: Float,
             code: Int, isDay: Boolean, paint: Paint) {
        val grey = Color.rgb(229, 239, 248)
        val cyan = Color.rgb(136, 215, 234)
        val gold = Color.rgb(255, 211, 144)
        paint.style = Paint.Style.FILL
        paint.alpha = 255
        val isClear = code == 0
        val isPartly = code == 1 || code == 2
        val rainy = code in rainCodes || code >= 95
        val snowy = code in snowCodes
        val foggy = code == 45 || code == 48

        if (isClear || isPartly) {
            if (isDay) {
                paint.color = gold
                val sx = centerX + if (isPartly) -radius * .34f else 0f
                val sy = centerY + if (isPartly) -radius * .25f else 0f
                canvas.drawCircle(sx, sy, radius * .39f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = radius * .08f
                paint.strokeCap = Paint.Cap.ROUND
                for (a in 0..7) {
                    val angle = Math.PI * a / 4.0
                    canvas.drawLine(
                        sx + cos(angle).toFloat() * radius * .56f,
                        sy + sin(angle).toFloat() * radius * .56f,
                        sx + cos(angle).toFloat() * radius * .72f,
                        sy + sin(angle).toFloat() * radius * .72f, paint
                    )
                }
                paint.style = Paint.Style.FILL
            } else {
                paint.color = gold
                canvas.drawCircle(centerX, centerY, radius * .53f, paint)
                paint.color = Color.rgb(28, 46, 62)
                canvas.drawCircle(centerX + radius * .25f, centerY - radius * .19f, radius * .45f, paint)
            }
        }
        if (!isClear || (isPartly && isDay)) {
            paint.style = Paint.Style.FILL
            paint.color = grey
            val cx = centerX + if (isPartly) radius * .13f else 0f
            val cy = centerY + if (rainy || snowy) -radius * .13f else radius * .1f
            val width = radius * 1.39f
            canvas.drawRoundRect(
                RectF(cx - width / 2f, cy, cx + width / 2f, cy + radius * .44f),
                radius * .20f, radius * .20f, paint
            )
            canvas.drawCircle(cx - radius * .33f, cy + radius * .02f, radius * .34f, paint)
            canvas.drawCircle(cx + radius * .08f, cy - radius * .18f, radius * .47f, paint)
            canvas.drawCircle(cx + radius * .42f, cy + radius * .07f, radius * .26f, paint)
        }
        if (rainy) {
            paint.color = cyan
            paint.strokeWidth = radius * .085f
            paint.strokeCap = Paint.Cap.ROUND
            for (i in -1..1) {
                val x = centerX + radius * i * .38f
                canvas.drawLine(x + radius * .1f, centerY + radius * .58f,
                    x - radius * .06f, centerY + radius * .88f, paint)
            }
        } else if (snowy) {
            paint.color = cyan
            paint.strokeWidth = radius * .08f
            paint.strokeCap = Paint.Cap.ROUND
            for (i in -1..1) {
                val x = centerX + radius * i * .4f
                val y = centerY + radius * .72f
                canvas.drawLine(x-radius*.1f,y,x+radius*.1f,y,paint)
                canvas.drawLine(x,y-radius*.1f,x,y+radius*.1f,paint)
            }
        } else if (foggy) {
            paint.color = cyan
            paint.strokeWidth = radius * .085f
            for (i in 0..1) {
                val y = centerY + radius * (.60f + .18f * i)
                canvas.drawLine(centerX-radius*.57f,y,centerX+radius*.57f,y,paint)
            }
        }
        if (code >= 95) {
            paint.color = gold
            val path = Path().apply {
                moveTo(centerX + radius*.03f,centerY+radius*.42f)
                lineTo(centerX - radius*.23f,centerY+radius*.78f)
                lineTo(centerX + radius*.04f,centerY+radius*.78f)
                lineTo(centerX - radius*.10f,centerY+radius*1.02f)
                lineTo(centerX + radius*.36f,centerY+radius*.62f)
                lineTo(centerX + radius*.12f,centerY+radius*.62f)
                close()
            }
            canvas.drawPath(path,paint)
        }
        paint.alpha = 255
    }
}
