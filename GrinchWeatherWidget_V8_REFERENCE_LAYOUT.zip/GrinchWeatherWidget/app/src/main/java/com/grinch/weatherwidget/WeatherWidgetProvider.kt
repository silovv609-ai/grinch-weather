package com.grinch.weatherwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WeatherWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            showStartingWidget(context, manager, id)
        }
        WidgetRefreshScheduler.ensureScheduled(context)
        WidgetRefreshScheduler.refreshNow(context)
    }

    override fun onEnabled(context: Context) {
        WidgetRefreshScheduler.ensureScheduled(context)
    }

    override fun onDisabled(context: Context) {
        // No widgets on home screen: avoid unnecessary periodic API requests.
        WidgetRefreshScheduler.stopPeriodic(context)
    }

    companion object {
        private fun iconForCode(code: Int, isDay: Boolean): Int = when (code) {
            0 -> if (isDay) R.drawable.ic_widget_sun else R.drawable.ic_widget_moon
            1, 2 -> if (isDay) R.drawable.ic_widget_partly else R.drawable.ic_widget_moon
            45, 48 -> R.drawable.ic_widget_fog
            51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> R.drawable.ic_widget_rain
            71, 73, 75, 77, 85, 86 -> R.drawable.ic_widget_snow
            95, 96, 99 -> R.drawable.ic_widget_storm
            else -> R.drawable.ic_widget_cloud
        }

        private fun openForecast(context: Context, widgetId: Int): PendingIntent {
            val intent = Intent(context, MainActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context, widgetId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun showStartingWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            val city = if (WeatherPlaces.isGeoEnabled(context)) "Моя геолокація"
                else prefs.getString("default_city", null)
            val views = RemoteViews(context.packageName, R.layout.widget_weather)
            views.setOnClickPendingIntent(R.id.widgetRoot, openForecast(context, id))
            views.setTextViewText(R.id.cityText, city ?: "Оберіть місто")
            views.setTextViewText(R.id.conditionText, if (city.isNullOrBlank())
                "Натисни для вибору міста" else "Оновлюємо погоду…")
            views.setTextViewText(R.id.detailsText, "Вітер — м/с")
            views.setTextViewText(R.id.precipitationText, "Опади — мм")
            views.setTextViewText(R.id.tempText, "--°")
            views.setImageViewResource(R.id.iconView, R.drawable.ic_widget_cloud)
            manager.updateAppWidget(id, views)
        }

        // Called after city settings change or a launcher widget update.
        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            showStartingWidget(context, manager, widgetId)
            WidgetRefreshScheduler.refreshNow(context)
        }

        // Runs inside a WorkManager Worker, not on the UI/broadcast receiver thread.
        fun updateWidgetBlocking(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            val city = if (WeatherPlaces.isGeoEnabled(context)) "Моя геолокація"
                else prefs.getString("default_city", null)
            if (city.isNullOrBlank()) {
                showStartingWidget(context, manager, widgetId)
                return
            }
            try {
                val forecast = WeatherApi.fetch(context)
                val views = RemoteViews(context.packageName, R.layout.widget_weather)
                views.setOnClickPendingIntent(R.id.widgetRoot, openForecast(context, widgetId))
                views.setTextViewText(R.id.cityText, forecast.city)
                views.setTextViewText(R.id.tempText, "${forecast.temperature}°")
                views.setImageViewResource(R.id.iconView, iconForCode(forecast.code, forecast.isDay))
                views.setTextViewText(R.id.conditionText,
                    forecast.description + if (forecast.cached) " · останні дані" else "")
                views.setTextViewText(
                    R.id.detailsText,
                    "Вітер ${WeatherApi.speed(forecast.wind)} м/с ${WeatherApi.arrow(forecast.windDegrees)}"
                )
                views.setTextViewText(
                    R.id.precipitationText,
                    "Опади зараз: ${WeatherApi.mm(forecast.precipitation)} мм"
                )
                manager.updateAppWidget(widgetId, views)
            } catch (error: Exception) {
                android.util.Log.e("GrinchWeather", "Widget refresh failed", error)
                // Keep the last successful reading displayed when the network is temporarily down.
                val views = RemoteViews(context.packageName, R.layout.widget_weather)
                views.setOnClickPendingIntent(R.id.widgetRoot, openForecast(context, widgetId))
                views.setTextViewText(R.id.cityText, city)
                views.setTextViewText(R.id.conditionText, "Немає оновлення · натисни для деталей")
                manager.partiallyUpdateAppWidget(widgetId, views)
            }
        }
    }
}
