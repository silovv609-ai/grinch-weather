package com.grinch.weatherwidget

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicBoolean

/** Uses foreground location permission only; background workers use the last saved coordinates. */
object LocationHelper {
    fun hasPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun request(context: Context, callback: (Location?) -> Unit) {
        if (!hasPermission(context)) { callback(null); return }
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val handler = Handler(Looper.getMainLooper())
        val delivered = AtomicBoolean(false)
        val provider = try {
            when {
                manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                manager.isProviderEnabled(LocationManager.GPS_PROVIDER) &&
                    context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED -> LocationManager.GPS_PROVIDER
                else -> null
            }
        } catch (_: Exception) { null }
        if (provider == null) { callback(null); return }
        var fallback: Location? = null
        try { fallback = manager.getLastKnownLocation(provider) } catch (_: SecurityException) { }
        val remembered = fallback
        fun finish(location: Location?) {
            if (delivered.compareAndSet(false, true)) callback(location ?: remembered)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val cancel = CancellationSignal()
                handler.postDelayed({ cancel.cancel(); finish(null) }, 18000)
                val executor = Executor { runnable -> handler.post(runnable) }
                manager.getCurrentLocation(provider, cancel, executor) { location -> finish(location) }
            } else {
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        manager.removeUpdates(this)
                        finish(location)
                    }
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                    override fun onProviderEnabled(provider: String) = Unit
                    override fun onProviderDisabled(provider: String) = Unit
                }
                manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
                handler.postDelayed({
                    manager.removeUpdates(listener)
                    finish(null)
                }, 18000)
            }
        } catch (_: Exception) { finish(null) }
    }
}
