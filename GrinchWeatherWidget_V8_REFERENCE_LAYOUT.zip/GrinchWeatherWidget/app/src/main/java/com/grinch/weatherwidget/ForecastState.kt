package com.grinch.weatherwidget

/** Latest forecast in the current app process for instant fullscreen chart opening. */
object ForecastState {
    var last: WeatherApi.Forecast? = null
}
