package com.grinch.weatherwidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/** City/village lookup, foreground location toggle and collapsible refresh interval. */
class ConfigActivity : Activity() {
    companion object { private const val LOCATION_REQUEST = 8713 }
    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID
    private lateinit var input: EditText
    private lateinit var searchButton: Button
    private lateinit var selectedLabel: TextView
    private lateinit var geoSwitch: Switch
    private lateinit var geoStatus: TextView
    private lateinit var autoSwitch: Switch
    private lateinit var intervalPicker: NumberPicker
    private lateinit var intervalLabel: TextView
    private lateinit var intervalHeader: LinearLayout
    private lateinit var intervalOptions: LinearLayout
    private lateinit var intervalChevron: TextView
    private lateinit var saveButton: Button
    private lateinit var windSwitch: Switch
    private lateinit var windLimitPicker: NumberPicker
    private var selectedPlace: WeatherPlaces.Place? = null
    private var currentLocation: Location? = null
    private var searching = false
    private var isSaving = false
    private var expanded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        window.statusBarColor = Color.rgb(5, 12, 9)
        window.navigationBarColor = Color.rgb(5, 12, 9)
        setContentView(R.layout.activity_config)
        widgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)

        input = findViewById(R.id.cityInput)
        searchButton = findViewById(R.id.findPlaceButton)
        selectedLabel = findViewById(R.id.selectedPlaceText)
        geoSwitch = findViewById(R.id.geoLocationSwitch)
        geoStatus = findViewById(R.id.geoStatus)
        autoSwitch = findViewById(R.id.autoRefreshSwitch)
        intervalPicker = findViewById(R.id.intervalPicker)
        intervalLabel = findViewById(R.id.intervalLabel)
        intervalHeader = findViewById(R.id.intervalHeader)
        intervalOptions = findViewById(R.id.intervalOptions)
        intervalChevron = findViewById(R.id.intervalChevron)
        saveButton = findViewById(R.id.saveButton)
        windSwitch = findViewById(R.id.droneIndicatorSwitch)
        windLimitPicker = findViewById(R.id.droneWindLimit)
        val windPrefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        windSwitch.isChecked = windPrefs.getBoolean("drone_indicator_enabled", true)
        windLimitPicker.minValue = 1
        windLimitPicker.maxValue = 30
        windLimitPicker.wrapSelectorWheel = false
        windLimitPicker.value = windPrefs.getInt("drone_wind_limit", 10).coerceIn(1, 30)
        windLimitPicker.isEnabled = windSwitch.isChecked
        windSwitch.setOnCheckedChangeListener { _, checked ->
            windLimitPicker.isEnabled = checked
            windLimitPicker.alpha = if (checked) 1f else .45f
        }

        input.setText(WeatherPlaces.manualCity(this))
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                selectedPlace = null
                selectedLabel.text = "Натисни «Знайти», щоб вибрати потрібне село або місто"
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        val prefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
        val manualLat = prefs.getFloat("manual_lat", 9999f)
        val manualLon = prefs.getFloat("manual_lon", 9999f)
        if (manualLat != 9999f && manualLon != 9999f) {
            selectedPlace = WeatherPlaces.Place(WeatherPlaces.manualCity(this),
                manualLat.toDouble(), manualLon.toDouble())
            selectedLabel.text = "Вибрано: ${selectedPlace?.name}"
        }

        autoSwitch.isChecked = WidgetRefreshScheduler.isEnabled(this)
        intervalPicker.minValue = 1
        intervalPicker.maxValue = 24
        intervalPicker.wrapSelectorWheel = false
        intervalPicker.value = WidgetRefreshScheduler.intervalHours(this)
        intervalOptions.visibility = View.GONE
        intervalChevron.text = "⌄"
        updateInterval()
        intervalHeader.setOnClickListener {
            expanded = !expanded
            intervalOptions.visibility = if (expanded) View.VISIBLE else View.GONE
            intervalChevron.text = if (expanded) "⌃" else "⌄"
        }
        autoSwitch.setOnCheckedChangeListener { _, _ -> updateInterval() }
        intervalPicker.setOnValueChangedListener { _, _, _ -> updateInterval() }

        geoSwitch.isChecked = WeatherPlaces.isGeoEnabled(this)
        updateGeoUI()
        geoSwitch.setOnCheckedChangeListener { _, enabled ->
            updateGeoUI()
            if (enabled) requestGeo()
        }

        searchButton.setOnClickListener {
            val query = input.text.toString().trim()
            if (query.isBlank()) {
                Toast.makeText(this, "Введи місто або село", Toast.LENGTH_SHORT).show()
            } else if (!searching) {
                searchPlaces(query, saveAfterChoice = false)
            }
        }
        saveButton.setOnClickListener { save() }
    }

    private fun updateGeoUI() {
        val enabled = geoSwitch.isChecked
        input.isEnabled = !enabled
        searchButton.isEnabled = !enabled
        input.alpha = if (enabled) .45f else 1f
        searchButton.alpha = if (enabled) .45f else 1f
        geoStatus.text = when {
            !enabled -> "Вимкнено — обраний населений пункт"
            currentLocation != null -> {
                val location = currentLocation!!
                "Місце визначено: %.4f, %.4f".format(java.util.Locale.US, location.latitude, location.longitude)
            }
            WeatherPlaces.isGeoEnabled(this) && WeatherPlaces.current(this) != null ->
                "Використовуємо останні збережені координати"
            else -> "Потрібен дозвіл на геолокацію телефона"
        }
    }

    private fun requestGeo() {
        if (!LocationHelper.hasPermission(this)) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_REQUEST)
            return
        }
        geoStatus.text = "Визначаємо координати…"
        LocationHelper.request(this) { result ->
            if (isFinishing || isDestroyed) return@request
            currentLocation = result
            updateGeoUI()
            val prefs = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            if (result == null && prefs.getFloat("geo_lat", 9999f) == 9999f) {
                Toast.makeText(this, "Не отримано координати. Увімкни геолокацію в телефоні.",
                    Toast.LENGTH_LONG).show()
                isSaving = false
            } else if (isSaving) {
                finishGeoSave()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_REQUEST) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
                requestGeo()
            } else {
                geoSwitch.isChecked = false
                isSaving = false
                Toast.makeText(this, "Дозвіл не надано. Обери населений пункт вручну.",
                    Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun hourWord(hours: Int): String = when {
        hours % 10 == 1 && hours % 100 != 11 -> "годину"
        hours % 10 in 2..4 && hours % 100 !in 12..14 -> "години"
        else -> "годин"
    }

    private fun updateInterval() {
        intervalPicker.isEnabled = autoSwitch.isChecked
        intervalPicker.alpha = if (autoSwitch.isChecked) 1f else .45f
        val hours = intervalPicker.value
        intervalLabel.text = if (autoSwitch.isChecked) {
            "Оновлювати кожні $hours ${hourWord(hours)}"
        } else "Автооновлення вимкнено"
    }

    private fun searchPlaces(query: String, saveAfterChoice: Boolean) {
        if (searching) return
        searching = true
        searchButton.isEnabled = false
        selectedLabel.text = "Шукаємо населений пункт…"
        thread(name = "GrinchPlaceSearch") {
            try {
                val results = WeatherPlaces.search(query)
                runOnUiThread {
                    searching = false
                    searchButton.isEnabled = !geoSwitch.isChecked
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (results.isEmpty()) {
                        selectedLabel.text = "Не знайдено. Спробуй інше написання або координати."
                        Toast.makeText(this, "Населений пункт не знайдено", Toast.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    AlertDialog.Builder(this)
                        .setTitle("Обери точне місце")
                        .setItems(results.map { it.title }.toTypedArray()) { _, index ->
                            val place = results[index]
                            input.setText(place.name)
                            selectedPlace = place
                            selectedLabel.text = "Обрано: ${place.title}"
                            if (saveAfterChoice) commit(geo = false, place = place)
                        }
                        .setNegativeButton("Скасувати", null)
                        .show()
                }
            } catch (error: Exception) {
                runOnUiThread {
                    searching = false
                    searchButton.isEnabled = !geoSwitch.isChecked
                    selectedLabel.text = "Не вдалося виконати пошук"
                    Toast.makeText(this, error.message ?: "Помилка пошуку", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun save() {
        if (searching) return
        if (geoSwitch.isChecked) {
            isSaving = true
            if (currentLocation != null) finishGeoSave()
            else requestGeo()
            return
        }
        val typed = input.text.toString().trim()
        if (typed.isBlank()) {
            Toast.makeText(this, "Введи назву міста або села", Toast.LENGTH_SHORT).show()
            return
        }
        val known = selectedPlace
        if (known != null && known.name == typed) {
            commit(geo = false, place = known)
        } else {
            // Save can trigger one explicit manual search; the user chooses from the results.
            searchPlaces(typed, saveAfterChoice = true)
        }
    }

    private fun finishGeoSave() {
        val location = currentLocation
        if (location != null) {
            WeatherPlaces.saveGeoCoordinates(this, location.latitude, location.longitude)
        } else if (getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
                .getFloat("geo_lat", 9999f) == 9999f) {
            isSaving = false
            Toast.makeText(this, "Координати недоступні", Toast.LENGTH_LONG).show()
            return
        }
        commit(geo = true, place = null)
    }

    private fun commit(geo: Boolean, place: WeatherPlaces.Place?) {
        if (geo) {
            WeatherPlaces.setGeoEnabled(this, true)
        } else {
            if (place == null) return
            WeatherPlaces.saveManual(this, place)
        }
        getSharedPreferences("weather_prefs", Context.MODE_PRIVATE).edit()
            .putBoolean("drone_indicator_enabled", windSwitch.isChecked)
            .putInt("drone_wind_limit", windLimitPicker.value)
            .apply()
        WidgetRefreshScheduler.saveSettings(this, autoSwitch.isChecked, intervalPicker.value)
        val manager = AppWidgetManager.getInstance(this)
        val widgetIds = manager.getAppWidgetIds(
            android.content.ComponentName(this, WeatherWidgetProvider::class.java))
        val name = if (geo) "Моя геолокація" else place?.name ?: ""
        getSharedPreferences("weather_prefs", Context.MODE_PRIVATE).edit().apply {
            widgetIds.forEach { putString("city_$it", name) }
        }.apply()
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        } else setResult(RESULT_OK)
        ForecastState.last = null
        WidgetRefreshScheduler.refreshNow(this)
        Toast.makeText(this, "Налаштування збережено", Toast.LENGTH_SHORT).show()
        finish()
    }
}
