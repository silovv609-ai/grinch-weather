package com.grinch.weatherwidget

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

/** Android controller for the proportional canvas layout based on the approved design. */
class MainActivity : Activity(), NeonDashboardView.Callbacks {
    private lateinit var dashboard: NeonDashboardView
    private lateinit var swipe: SwipeRefreshLayout
    private val handler = Handler(Looper.getMainLooper())
    private var requestSerial = 0
    private var displayedKey: String? = null
    private var lastUpdated = 0L
    private val ukrainian = Locale.forLanguageTag("uk-UA")

    private val tick = object: Runnable {
        override fun run() {
            dashboard.invalidate()
            handler.postDelayed(this, 60_000L)
        }
    }
    private val periodicTick = object: Runnable {
        override fun run() {
            if (WidgetRefreshScheduler.isEnabled(this@MainActivity)) {
                load(true)
                scheduleOpenedAppRefresh()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.navigationBarColor = Color.rgb(3, 11, 7)
        setContentView(R.layout.activity_main)
        dashboard = findViewById(R.id.dashboard)
        swipe = findViewById(R.id.pullToRefresh)
        swipe.setColorSchemeColors(Color.rgb(82,250,135))
        swipe.setProgressBackgroundColorSchemeColor(Color.rgb(5,20,10))
        swipe.setOnRefreshListener { load(true) }
        dashboard.callbacks = this
        WidgetRefreshScheduler.ensureScheduled(this)
    }

    override fun onResume() {
        super.onResume()
        val key = currentKey()
        val old = ForecastState.last
        if (key == displayedKey && old != null) dashboard.forecast = old
        val refreshIntervalMs = WidgetRefreshScheduler.intervalHours(this).toLong() * 3_600_000L
        val isStale = lastUpdated <= 0L || SystemClock.elapsedRealtime() - lastUpdated > refreshIntervalMs
        if (isStale || displayedKey != key) load(true)
        if (WeatherPlaces.isGeoEnabled(this) && LocationHelper.hasPermission(this)) {
            LocationHelper.request(this) { location ->
                if (location != null && !isFinishing && !isDestroyed) {
                    val oldPlace = WeatherPlaces.current(this)
                    if (oldPlace == null || abs(oldPlace.latitude-location.latitude) > .004 ||
                        abs(oldPlace.longitude-location.longitude) > .004) {
                        WeatherPlaces.saveGeoCoordinates(this,location.latitude,location.longitude)
                        load(true)
                    }
                }
            }
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        scheduleOpenedAppRefresh()
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(periodicTick)
        super.onPause()
    }

    override fun onDestroy() {
        requestSerial++
        super.onDestroy()
    }

    override fun openSettings() { startActivity(Intent(this, ConfigActivity::class.java)) }
    override fun openHours() { startActivity(Intent(this, HourlyDetailActivity::class.java)) }
    override fun refresh() { load(true) }

    override fun openDay(day: WeatherApi.Day, hasHourly: Boolean) {
        val riskIsShown = getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            .getBoolean("show_fog_risk", false)
        val fogLine = if (riskIsShown) "\nОрієнтовний ризик туману: ${day.fogRisk}%" else ""
        val title = day.date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", ukrainian))
        val message = "Температура: ${day.min}…${day.max} °C\n" +
            "Вітер: ${WeatherApi.speed(day.wind)} м/с ${WeatherApi.arrow(day.degrees)}\n" +
            "Максимальні пориви: ${WeatherApi.speed(day.gust)} м/с\n" +
            "Опади: ${WeatherApi.mm(day.precipitation)} мм (${day.rain}%)" + fogLine
        val dialog = AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setNegativeButton("Закрити", null)
        if (hasHourly) dialog.setPositiveButton("По годинах") { _, _ ->
            startActivity(Intent(this, HourlyDetailActivity::class.java).apply {
                putExtra("target_date", day.date.toString())
            })
        }
        dialog.show()
    }

    private fun scheduleOpenedAppRefresh() {
        handler.removeCallbacks(periodicTick)
        if (WidgetRefreshScheduler.isEnabled(this)) {
            handler.postDelayed(periodicTick,
                WidgetRefreshScheduler.intervalHours(this).toLong() * 3_600_000L)
        }
    }

    private fun currentKey(): String {
        val place = WeatherPlaces.current(this)
        return if (place != null) {
            "${if (WeatherPlaces.isGeoEnabled(this)) "geo" else "manual"}:${place.latitude}:${place.longitude}"
        } else if (WeatherPlaces.isGeoEnabled(this)) "geo:pending"
        else "legacy:${WeatherPlaces.manualCity(this)}"
    }

    private fun load(force: Boolean) {
        val key = currentKey()
        if (key == "legacy:") {
            swipe.isRefreshing = false
            if (!isFinishing) openSettings()
            return
        }
        if (key == "geo:pending") {
            Toast.makeText(this,"Увімкни геолокацію або обери місто в налаштуваннях",Toast.LENGTH_LONG).show()
            swipe.isRefreshing = false
            return
        }
        if (!force && key == displayedKey && lastUpdated > 0L) { swipe.isRefreshing = false; return }
        displayedKey = key
        dashboard.loading = true
        val request = ++requestSerial
        thread(name="GrinchExactDesignWeather") {
            try {
                val result = WeatherApi.fetch(applicationContext)
                runOnUiThread {
                    if (isDestroyed || isFinishing || request != requestSerial) return@runOnUiThread
                    ForecastState.last = result
                    dashboard.forecast = result
                    dashboard.loading = false
                    swipe.isRefreshing = false
                    lastUpdated = SystemClock.elapsedRealtime()
                    WidgetRefreshScheduler.refreshNow(this)
                    if (result.cached) Toast.makeText(this,
                        "Немає мережі. Показано збережений прогноз",Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                android.util.Log.e("GrinchWeather","Forecast refresh",e)
                runOnUiThread {
                    if (isDestroyed || isFinishing || request != requestSerial) return@runOnUiThread
                    dashboard.loading = false
                    swipe.isRefreshing = false
                    Toast.makeText(this,"Помилка прогнозу: ${e.message ?: "перевір інтернет"}",Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
