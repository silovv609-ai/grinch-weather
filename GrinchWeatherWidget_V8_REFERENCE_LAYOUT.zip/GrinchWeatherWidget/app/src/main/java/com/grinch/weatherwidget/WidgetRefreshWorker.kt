package com.grinch.weatherwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

/** Runs in background so an Android widget still updates when the app screen is closed. */
class WidgetRefreshWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val context = applicationContext
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, WeatherWidgetProvider::class.java))
        for (id in ids) {
            if (isStopped) break
            WeatherWidgetProvider.updateWidgetBlocking(context, manager, id)
        }
        return Result.success()
    }
}
