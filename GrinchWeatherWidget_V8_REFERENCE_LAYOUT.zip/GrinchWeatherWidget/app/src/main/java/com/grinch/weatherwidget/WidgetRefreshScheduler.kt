package com.grinch.weatherwidget

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/** WorkManager provides approximate periodic background updates, including after reboot. */
object WidgetRefreshScheduler {
    private const val PREFS = "weather_prefs"
    private const val AUTO_ENABLED = "auto_refresh_enabled"
    private const val HOURS = "auto_refresh_hours"
    private const val PERIODIC_NAME = "grinch-weather-widget-periodic"
    private const val ON_DEMAND_NAME = "grinch-weather-widget-now"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(AUTO_ENABLED, true)

    fun intervalHours(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(HOURS, 3).coerceIn(1, 24)

    private fun constraints(): Constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    fun ensureScheduled(context: Context) {
        if (isEnabled(context)) {
            val request = PeriodicWorkRequestBuilder<WidgetRefreshWorker>(
                intervalHours(context).toLong(), TimeUnit.HOURS
            )
                .setConstraints(constraints())
                .build()
            WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                PERIODIC_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }
    }

    fun saveSettings(context: Context, enabled: Boolean, hours: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(AUTO_ENABLED, enabled)
            .putInt(HOURS, hours.coerceIn(1, 24))
            .apply()
        val manager = WorkManager.getInstance(context.applicationContext)
        if (!enabled) {
            manager.cancelUniqueWork(PERIODIC_NAME)
        } else {
            val request = PeriodicWorkRequestBuilder<WidgetRefreshWorker>(
                hours.coerceIn(1, 24).toLong(), TimeUnit.HOURS
            )
                .setConstraints(constraints())
                .build()
            manager.enqueueUniquePeriodicWork(
                PERIODIC_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
            )
        }
    }

    fun refreshNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<WidgetRefreshWorker>()
            .setConstraints(constraints())
            .build()
        WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
            ON_DEMAND_NAME, ExistingWorkPolicy.REPLACE, request
        )
    }

    fun stopPeriodic(context: Context) {
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(PERIODIC_NAME)
    }
}
