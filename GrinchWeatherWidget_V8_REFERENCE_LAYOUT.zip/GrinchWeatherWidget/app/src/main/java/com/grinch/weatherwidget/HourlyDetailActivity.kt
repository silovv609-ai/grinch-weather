package com.grinch.weatherwidget

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.concurrent.thread

/** Immersive detail for the seven-day hourly timeline. Tapping the card opens this screen. */
class HourlyDetailActivity : Activity() {
    private lateinit var scroll: HorizontalScrollView
    private lateinit var timeline: HourlyTimelineView
    private lateinit var tabsScroll: HorizontalScrollView
    private lateinit var tabs: LinearLayout
    private lateinit var title: TextView
    private lateinit var cityTitle: TextView
    private lateinit var hint: TextView
    private val dates = ArrayList<LocalDate>()
    private val hours = ArrayList<WeatherApi.Hour>()
    private val buttons = ArrayList<TextView>()
    private var activeDay = -1
    private val locale = Locale.forLanguageTag("uk-UA")
    private fun dp(v: Int) = (resources.displayMetrics.density * v + .5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.navigationBarColor = Color.rgb(5, 12, 9)
        setContentView(R.layout.activity_hourly_detail)
        findViewById<TextView>(R.id.detailBack).setOnClickListener { finish() }
        scroll = findViewById(R.id.detailHourlyScroll)
        timeline = findViewById(R.id.detailHourlyTimeline)
        tabsScroll = findViewById(R.id.detailTabsScroll)
        tabs = findViewById(R.id.detailTabs)
        title = findViewById(R.id.detailDate)
        cityTitle = findViewById(R.id.detailCity)
        hint = findViewById(R.id.detailHint)
        timeline.setExpanded(true)
        scroll.setOnScrollChangeListener { _: View, x: Int, _: Int, _: Int, _: Int ->
            if (hours.isNotEmpty()) {
                val i = (x / timeline.columnWidthPx).coerceIn(0, hours.lastIndex)
                val day = dates.indexOf(hours[i].time.toLocalDate())
                if (day >= 0) select(day)
            }
        }
        val latest = ForecastState.last
        if (latest != null) render(latest) else {
            thread(name = "GrinchFullScreenForecast") {
                try {
                    val f = WeatherApi.fetch(applicationContext)
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) { ForecastState.last = f; render(f) }
                    }
                } catch (error: Exception) {
                    runOnUiThread {
                        hint.text = "Не вдалося завантажити: ${error.message}"
                    }
                }
            }
        }
    }

    private fun render(f: WeatherApi.Forecast) {
        cityTitle.text = f.city + if (f.cached) " · останні збережені дані" else " · 7 днів"
        hours.clear(); hours.addAll(f.hours)
        dates.clear(); dates.addAll(hours.map { it.time.toLocalDate() }.distinct())
        timeline.setForecast(f.hours, f.currentTime, f.days)
        tabs.removeAllViews(); buttons.clear()
        for ((i, date) in dates.withIndex()) {
            val dateText = date.format(DateTimeFormatter.ofPattern("dd.MM", locale))
            val dayName = date.format(DateTimeFormatter.ofPattern("EE", locale))
            val button = TextView(this).apply {
                text = "${dayName.replaceFirstChar { it.uppercase() }}\n$dateText"
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(Color.rgb(207, 225, 241))
                setBackgroundResource(R.drawable.chip_unselected_bg)
                setOnClickListener {
                    val index = hours.indexOfFirst { it.time.toLocalDate() == date }
                    if (index >= 0) scroll.smoothScrollTo(index * timeline.columnWidthPx, 0)
                    select(i)
                }
            }
            tabs.addView(button, LinearLayout.LayoutParams(dp(90), dp(60)).apply { rightMargin = dp(7) })
            buttons.add(button)
        }
        activeDay = -1
        val targetDate = intent.getStringExtra("target_date")
            ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val firstHour = if (targetDate != null) {
            hours.indexOfFirst { it.time.toLocalDate() == targetDate }.coerceAtLeast(0)
        } else {
            hours.indexOfFirst {
                !it.time.isBefore(f.currentTime.withMinute(0).withSecond(0).withNano(0))
            }.coerceAtLeast(0)
        }
        scroll.post {
            scroll.scrollTo(firstHour * timeline.columnWidthPx, 0)
            val day = dates.indexOf(hours[firstHour].time.toLocalDate())
            select(day.coerceAtLeast(0))
        }
    }

    private fun select(index: Int) {
        if (index !in dates.indices || index == activeDay) return
        activeDay = index
        title.text = dates[index].format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale))
            .replaceFirstChar { it.uppercase() }
        buttons.forEachIndexed { i, button ->
            button.setBackgroundResource(if (i == index) R.drawable.chip_selected_bg else R.drawable.chip_unselected_bg)
            button.setTextColor(if (i == index) Color.rgb(12, 36, 46) else Color.rgb(207, 225, 241))
        }
        tabsScroll.smoothScrollTo(buttons[index].left - dp(12), 0)
    }
}
