package com.grinch.weatherwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Pixel-proportional neon dashboard. The reference art is 864 x 1536.
 * Drawn text, icons, forecast values and cards are all live Android Canvas elements,
 * NOT a screenshot and not prefilled demo weather values.
 * Every element shares the same WIDTH-based scale factor: no oversized dp cards.
 */
class NeonDashboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    interface Callbacks {
        fun openSettings()
        fun openHours()
        fun openDay(day: WeatherApi.Day, hasHourly: Boolean)
        fun refresh()
    }

    var callbacks: Callbacks? = null
    var forecast: WeatherApi.Forecast? = null
        set(value) {
            field = value
            hourlyShift = 0
            dailyShift = 0
            fetchClock = SystemClock.elapsedRealtime()
            invalidate()
        }
    var loading = false
        set(value) { field = value; invalidate() }

    private val ukrainian = Locale.forLanguageTag("uk-UA")
    private val white = Color.rgb(245, 250, 249)
    private val neon = Color.rgb(82, 250, 135)
    private val shadowGreen = Color.rgb(21, 107, 54)
    private val muted = Color.rgb(161, 174, 171)
    private val red = Color.rgb(255, 76, 91)
    private val cyan = Color.rgb(30, 207, 235)
    private val yellow = Color.rgb(255, 218, 14)
    private val bkg = Color.rgb(2, 11, 7)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val reg = Typeface.create("sans-serif", Typeface.NORMAL)
    private val bold = Typeface.create("sans-serif", Typeface.BOLD)
    private val hero = BitmapFactory.decodeResource(resources, R.drawable.hero_drone)
    private val sunsetImage = BitmapFactory.decodeResource(resources, R.drawable.sunset_landscape)
    private val headerDrone = BitmapFactory.decodeResource(resources, R.drawable.header_drone)
    private val hoursStartY = 620f
    private val daysStartY = 907f
    private var hourlyShift = 0
    private var dailyShift = 0
    private var downX = 0f
    private var downY = 0f
    private var moving = false
    private var fetchClock = SystemClock.elapsedRealtime()

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        contentDescription = "GRINCH WEATHER. Натисніть назву для налаштувань; прогноз можна гортати."
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * 1536f / 864f).roundToInt())
    }

    private fun rounded(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float,
                        fill: Int, stroke: Int? = null, sw: Float = 1.5f, glow: Float = 0f) {
        val box = RectF(x, y, x + w, y + h)
        p.clearShadowLayer()
        p.shader = null
        p.color = fill
        p.style = Paint.Style.FILL
        if (glow > 0 && stroke != null) p.setShadowLayer(glow, 0f, 0f, stroke)
        c.drawRoundRect(box, r, r, p)
        p.clearShadowLayer()
        if (stroke != null) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = sw
            p.color = stroke
            c.drawRoundRect(box, r, r, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun text(c: Canvas, s: String, x: Float, baseline: Float, size: Float,
                     color: Int = white, isBold: Boolean = false,
                     align: Paint.Align = Paint.Align.LEFT, glow: Float = 0f) {
        p.clearShadowLayer()
        p.style = Paint.Style.FILL
        p.shader = null
        p.typeface = if (isBold) bold else reg
        p.textSize = size
        p.textAlign = align
        p.color = color
        if (glow > 0f) p.setShadowLayer(glow, 0f, 0f, color)
        c.drawText(s, x, baseline, p)
        p.clearShadowLayer()
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float,
                     color: Int, width: Float = 1f, glow: Float = 0f) {
        p.shader = null
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = width
        p.strokeCap = Paint.Cap.ROUND
        p.clearShadowLayer()
        if (glow > 0f) p.setShadowLayer(glow, 0f, 0f, color)
        c.drawLine(x1, y1, x2, y2, p)
        p.clearShadowLayer()
        p.style = Paint.Style.FILL
    }

    private fun image(c: Canvas, bitmap: Bitmap, box: RectF) {
        val bw = bitmap.width.toFloat()
        val bh = bitmap.height.toFloat()
        val targetAspect = box.width() / box.height()
        val sourceAspect = bw / bh
        val source = if (sourceAspect > targetAspect) {
            val sourceW = (bh * targetAspect).roundToInt()
            Rect((bitmap.width - sourceW) / 2, 0,
                (bitmap.width + sourceW) / 2, bitmap.height)
        } else {
            val sourceH = (bw / targetAspect).roundToInt()
            Rect(0, (bitmap.height - sourceH) / 2, bitmap.width,
                (bitmap.height + sourceH) / 2)
        }
        p.shader = null
        p.alpha = 255
        p.color = Color.WHITE
        c.drawBitmap(bitmap, source, box, p)
    }

    private fun boxImage(c: Canvas, bitmap: Bitmap, x: Float, y: Float, w: Float, h: Float,
                         radius: Float, dark: Boolean = true) {
        val save = c.save()
        val clip = Path().apply { addRoundRect(RectF(x, y, x + w, y + h), radius, radius, Path.Direction.CW) }
        c.clipPath(clip)
        image(c, bitmap, RectF(x, y, x + w, y + h))
        if (dark) {
            p.clearShadowLayer()
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(x, y, x + w * .95f, y + h * .32f,
                intArrayOf(Color.argb(211, 1, 13, 7), Color.argb(78, 1, 11, 6), Color.argb(14, 0, 0, 0)),
                null, Shader.TileMode.CLAMP)
            c.drawRect(RectF(x, y, x + w, y + h), p)
            p.shader = LinearGradient(x, y + h * .68f, x, y + h,
                Color.TRANSPARENT, Color.argb(110, 2, 18, 10), Shader.TileMode.CLAMP)
            c.drawRect(RectF(x, y, x + w, y + h), p)
            p.shader = null
        }
        c.restoreToCount(save)
    }

    private fun cloud(c: Canvas, x: Float, y: Float, size: Float, shade: Int = white) {
        // Three arcs and one lower edge make a clean outlined icon, as in the selected mockup.
        val q = size / 70f
        c.save()
        c.translate(x - 35f * q, y - 28f * q)
        c.scale(q, q)
        val cp = Path().apply {
            moveTo(16f, 52f)
            cubicTo(5f, 52f, 5f, 35f, 14f, 30f)
            cubicTo(15f, 22f, 23f, 16f, 31f, 18f)
            cubicTo(37f, 5f, 57f, 11f, 57f, 28f)
            cubicTo(74f, 29f, 75f, 49f, 60f, 52f)
            close()
        }
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4.5f
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.color = shade
        p.setShadowLayer(3f, 0f, 0f, shade)
        c.drawPath(cp, p)
        p.clearShadowLayer()
        p.style = Paint.Style.FILL
        c.restore()
    }

    private fun weatherIcon(c: Canvas, x: Float, y: Float, width: Float, code: Int, isDay: Boolean) {
        val isRain = code in 51..67 || code in 80..82 || code >= 95
        val isSnow = code in 71..77 || code in 85..86
        val isClear = code == 0
        val isPartly = code in 1..2
        val fog = code == 45 || code == 48
        val r = width * .29f
        if (isClear || isPartly) {
            val sx = if (isPartly) x - width * .17f else x
            val sy = if (isPartly) y - width * .13f else y
            if (isDay) {
                p.shader = null; p.style = Paint.Style.FILL; p.color = yellow
                p.setShadowLayer(4f, 0f, 0f, yellow)
                c.drawCircle(sx, sy, r, p)
                p.clearShadowLayer()
                for (i in 0..7) {
                    val a = i * Math.PI / 4.0
                    line(c, sx + cos(a).toFloat() * r * 1.34f,
                        sy + sin(a).toFloat() * r * 1.34f,
                        sx + cos(a).toFloat() * r * 1.76f,
                        sy + sin(a).toFloat() * r * 1.76f,
                        yellow, width * .052f)
                }
            } else {
                p.shader = null; p.color = white
                c.drawCircle(sx, sy, r, p)
                p.color = Color.rgb(6, 18, 11)
                c.drawCircle(sx + r * .36f, sy - r * .21f, r * .88f, p)
            }
        }
        if (!isClear || isPartly) {
            cloud(c, x + if (isPartly) width * .18f else 0f, y + if (isRain) -width * .11f else 0f, width * .88f)
        }
        if (isRain || isSnow) {
            for (i in -1..1) {
                val xx = x + i * width * .19f
                line(c, xx + 3f, y + width * .29f, xx - 3f, y + width * .51f,
                    if (isSnow) white else cyan, width * .07f)
            }
        } else if (fog) {
            for (i in 0..1) line(c, x - width * .35f, y + width * (.30f + .14f * i),
                x + width * .35f, y + width * (.30f + .14f * i), white, 3f)
        }
    }

    private fun windIcon(c: Canvas, x: Float, y: Float, size: Float, color: Int = neon) {
        for (i in 0..2) {
            val yy = y - size * .27f + i * size * .28f
            line(c, x - size * .48f, yy, x + size * .26f, yy, color, 3.5f, 1.6f)
            line(c, x + size * .26f, yy, x + size * .39f, yy - size * .07f, color, 3f)
        }
    }

    private fun rainIcon(c: Canvas, x: Float, y: Float, size: Float) {
        val r = size * .43f
        val path = Path().apply {
            moveTo(x, y - r)
            cubicTo(x - r * .35f, y - r * .40f, x - r, y + r * .23f, x - r * .65f, y + r * .67f)
            cubicTo(x - r * .28f, y + r * 1.16f, x + r * .57f, y + r * .95f, x + r * .70f, y + r * .27f)
            cubicTo(x + r * .75f, y, x + r * .33f, y - r * .58f, x, y - r)
            close()
        }
        p.shader = null; p.color = neon; p.style = Paint.Style.STROKE; p.strokeWidth = 3.5f
        c.drawPath(path, p); p.style = Paint.Style.FILL
    }

    private fun pin(c: Canvas, x: Float, y: Float) {
        p.shader = null; p.color = neon
        c.drawCircle(x, y - 5f, 11.5f, p)
        val path = Path().apply {
            moveTo(x - 10f, y)
            lineTo(x, y + 22f)
            lineTo(x + 10f, y)
            close()
        }
        c.drawPath(path, p)
        p.color = bkg
        c.drawCircle(x, y - 5f, 4.3f, p)
    }

    private fun sunIcon(c: Canvas, x: Float, y: Float, r: Float) {
        p.color = yellow; p.shader = null; p.style = Paint.Style.FILL
        c.drawCircle(x, y, r, p)
        for (i in 0..7) {
            val a = i * Math.PI / 4.0
            line(c, x + cos(a).toFloat() * r * 1.30f, y + sin(a).toFloat() * r * 1.30f,
                x + cos(a).toFloat() * r * 1.75f, y + sin(a).toFloat() * r * 1.75f, yellow, 3f)
        }
    }

    private fun clockIcon(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = neon; p.shader = null
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.FILL
        line(c, x, y, x, y - r * .6f, neon, 3f)
        line(c, x, y, x + r * .48f, y + r * .27f, neon, 3f)
    }

    private fun calendarIcon(c: Canvas, x: Float, y: Float) {
        p.style = Paint.Style.STROKE; p.color = neon; p.strokeWidth = 3f; p.shader = null
        c.drawRoundRect(RectF(x - 15f, y - 15f, x + 16f, y + 16f), 2f, 2f, p)
        p.style = Paint.Style.FILL
        line(c, x - 15f, y - 5f, x + 16f, y - 5f, neon, 3f)
        line(c, x - 8f, y - 20f, x - 8f, y - 11f, neon, 3f)
        line(c, x + 8f, y - 20f, x + 8f, y - 11f, neon, 3f)
    }

    private fun dayTitle(f: WeatherApi.Forecast?, i: Int): Pair<String,String> {
        val d = f?.days?.getOrNull(i)?.date
        if (d == null) return (if (i==0) "Сьогодні" else "--") to "--.--"
        val label = if (i == 0) "Сьогодні" else d.format(DateTimeFormatter.ofPattern("EE", ukrainian)).replaceFirstChar { it.uppercase(ukrainian) }
        return label to d.format(DateTimeFormatter.ofPattern("dd.MM"))
    }

    private fun hourList(f: WeatherApi.Forecast?): List<WeatherApi.Hour> {
        if (f == null) return emptyList()
        val hour = f.currentTime.withMinute(0).withSecond(0).withNano(0)
        return f.hours.filter { !it.time.isBefore(hour) }.take(24)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val sc = width / 864f
        val save = canvas.save()
        canvas.scale(sc, sc)
        canvas.drawColor(bkg)
        drawHeader(canvas)
        drawHero(canvas)
        drawHourly(canvas)
        drawDaily(canvas)
        drawSun(canvas)
        canvas.restoreToCount(save)
    }

    private fun drawHeader(c: Canvas) {
        image(c, headerDrone, RectF(24f, 37f, 156f, 96f))
        text(c, "GRINCH", 166f, 85f, 42f, neon, true, glow=1.3f)
        text(c, " WEATHER", 327f, 85f, 41f, white, true)
        rounded(c, 590f, 42f, 240f, 60f, 23f, Color.rgb(6, 21, 14), Color.rgb(30, 62, 45), 1.4f)
        // Monochrome fog icon + toggle. Click to toggle forecast fog notices.
        cloud(c, 630f, 69f, 32f)
        line(c, 615f, 84f, 644f, 84f, white, 2.2f)
        line(c, 620f, 89f, 640f, 89f, white, 1.8f)
        text(c, "Туман", 657f, 81f, 24f, white)
        val enabled = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            .getBoolean("show_fog_risk", false)
        rounded(c, 748f, 54f, 65f, 40f, 20f,
            if (enabled) Color.rgb(14, 113, 51) else Color.rgb(41, 45, 44))
        p.style = Paint.Style.FILL; p.color = white; p.shader = null
        c.drawCircle(if (enabled) 791f else 771f, 73f, 18f, p)
    }

    private fun drawHero(c: Canvas) {
        val f = forecast
        boxImage(c, hero, 35f, 128f, 795f, 406f, 27f)
        rounded(c, 35f, 128f, 795f, 406f, 27f, Color.TRANSPARENT, neon, 1.3f, 4f)
        pin(c, 73f, 173f)
        text(c, f?.city ?: "Оберіть місто", 105f, 188f, 36f, white, true)
        text(c, if (f == null) "--°" else "${f.temperature}°", 62f, 335f, 151f, white, true, glow=2.5f)
        weatherIcon(c, 93f, 379f, 64f, f?.code ?: 3, f?.isDay ?: true)
        text(c, f?.description ?: "Очікуємо прогноз", 142f, 393f, 31f, white, true)

        rounded(c, 55f, 420f, 213f, 96f, 21f, Color.argb(212, 2, 16, 10), Color.rgb(44, 83, 63), 1.2f)
        windIcon(c, 98f, 473f, 37f)
        text(c, "Вітер", 137f, 461f, 22f, Color.rgb(217, 222, 219))
        text(c, if (f == null) "— м/с" else "${WeatherApi.speed(f.wind)} м/с ${WeatherApi.arrow(f.windDegrees)}",
            137f, 492f, 28f, white, true)
        rounded(c, 284f, 420f, 229f, 96f, 21f, Color.argb(209, 2, 16, 10), Color.rgb(44, 83, 63), 1.2f)
        rainIcon(c, 327f, 469f, 42f)
        text(c, "Опади зараз", 369f, 460f, 21f, Color.rgb(217, 222, 219))
        text(c, if (f == null) "— мм" else "${WeatherApi.mm(f.precipitation)} мм", 369f, 491f, 28f, white, true)
        // No oversized red status badge: exact layout from the approved mockup.
        if (loading) text(c, "●", 793f, 503f, 22f, neon, true, glow = 4f)
    }

    private fun drawHourly(c: Canvas) {
        clockIcon(c, 59f, 583f, 19f)
        text(c, "Погода на 24 години", 93f, 596f, 32f, white, true)
        text(c, "Детальніше ›", 827f, 594f, 24f, neon, false, Paint.Align.RIGHT)
        rounded(c, 32f, 621f, 800f, 196f, 21f, Color.rgb(3, 14, 9), Color.rgb(33, 65, 45), 1.5f)
        val hours = hourList(forecast)
        val shift = hourlyShift
        val showEvery3 = shift == 0
        for (slot in 0..7) {
            val x = 37f + slot * 99.1f
            val w = 99.1f
            val idx = if (showEvery3) slot * 3 else shift + slot
            val hour = hours.getOrNull(idx)
            if (slot > 0) line(c, x, 649f, x, 796f, Color.rgb(22, 51, 35), 1f)
            if (slot == 0 && shift == 0) {
                rounded(c, x, 628f, w, 185f, 17f, Color.rgb(4, 27, 13), neon, 1.7f, 4f)
            }
            val head = if (slot == 0 && shift == 0) "Зараз"
                else hour?.time?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "--:--"
            text(c, head, x + w/2, 662f, 19f,
                if (slot == 0 && shift == 0) white else muted,
                slot == 0 && shift == 0, Paint.Align.CENTER)
            weatherIcon(c, x + w/2, 703f, 48f, hour?.code ?: 3, hour?.isDay ?: true)
            text(c, if (hour == null) "--°" else "${hour.temp}°", x + w/2, 759f,
                30f, white, true, Paint.Align.CENTER)
            val arrow = if (hour == null) "↑" else WeatherApi.arrow(hour.degrees)
            val speed = if (hour == null) "—" else WeatherApi.speed(hour.wind)
            text(c, arrow, x + 30f, 795f, 27f, neon, true, Paint.Align.CENTER)
            text(c, speed, x + 56f, 793f, 18f, muted, false, Paint.Align.CENTER)
        }
    }

    private fun drawDaily(c: Canvas) {
        calendarIcon(c, 57f, 868f)
        text(c, "Прогноз на 14 днів", 96f, 881f, 31f, white, true)
        text(c, "Детальніше ›", 827f, 881f, 24f, neon, false, Paint.Align.RIGHT)
        val f = forecast
        val maxGust = f?.days?.maxOfOrNull { it.gust } ?: 0.0
        for (slot in 0..6) {
            val i = slot + dailyShift
            val day = f?.days?.getOrNull(i)
            val x = 31f + slot * 115.2f
            val y = daysStartY
            val isToday = i == 0
            val strongest = day != null && maxGust > 0 && abs(maxGust - day.gust) < .0001
            val stroke = if (strongest) red else if (isToday) neon else Color.rgb(26, 63, 44)
            val fill = when {
                strongest -> Color.rgb(36, 8, 14)
                isToday -> Color.rgb(6, 28, 17)
                else -> Color.rgb(3, 15, 10)
            }
            rounded(c, x, y, 110f, 246f, 16f, fill, stroke,
                if (strongest || isToday) 1.7f else 1.2f,
                if (strongest || isToday) 3f else 0f)
            val (title, date) = dayTitle(f, i)
            text(c, title, x + 55f, 941f, if (title == "Сьогодні") 20f else 20f,
                if (strongest) white else white, isToday, Paint.Align.CENTER)
            text(c, date, x + 55f, 970f, 18f, if (strongest) red else muted,
                false, Paint.Align.CENTER)
            weatherIcon(c, x + 55f, 1012f, 52f, day?.code ?: 3, true)
            val t = if (day == null) "--° / --°" else "${day.max}° / ${day.min}°"
            text(c, t, x + 55f, 1067f, 23f, white, true, Paint.Align.CENTER)
            val direction = if (day == null) "↑" else WeatherApi.arrow(day.degrees)
            val speed = if (day == null) "—" else WeatherApi.speed(day.wind)
            text(c, direction, x + 30f, 1102f, 24f,
                if (strongest) red else neon, true, Paint.Align.CENTER)
            text(c, speed, x + 65f, 1100f, 18f,
                if (strongest) red else muted, false, Paint.Align.CENTER)
            windIcon(c, x + 31f, 1133f, 23f, if (strongest) red else neon)
            text(c, if (day==null) "—" else WeatherApi.speed(day.gust), x + 71f, 1137f, 18f,
                if (strongest) red else muted, false, Paint.Align.CENTER)
        }
    }

    private fun drawSun(c: Canvas) {
        val f = forecast
        boxImage(c, sunsetImage, 34f, 1180f, 797f, 299f, 26f, false)
        // Dark top and bottom, to retain readable typography over the photographed scene.
        p.shader = LinearGradient(34f, 1180f, 34f, 1479f,
            intArrayOf(Color.argb(193, 0, 12, 6), Color.argb(30, 3, 14, 6), Color.argb(210, 0, 11, 5)),
            null, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(34f,1180f,831f,1479f),26f,26f,p)
        p.shader = null
        rounded(c, 34f, 1180f, 797f, 299f, 26f, Color.TRANSPARENT,
            Color.rgb(35, 137, 72), 1.4f, 2f)
        sunIcon(c, 73f, 1217f, 10f)
        text(c, "Схід і захід сонця", 103f, 1228f, 27f, white, true)
        sunIcon(c, 80f, 1291f, 16f)
        sunIcon(c, 711f, 1291f, 16f)
        val rising = f?.sunrise
        val setting = f?.sunset
        text(c, "Схід", 122f, 1269f, 19f, muted)
        text(c, rising?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "--:--",
            122f, 1315f, 28f, white, true)
        text(c, "Захід", 769f, 1269f, 19f, muted, false, Paint.Align.RIGHT)
        text(c, setting?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "--:--",
            808f, 1315f, 28f, white, true, Paint.Align.RIGHT)
        rounded(c, 54f, 1366f, 757f, 14f, 8f,
            Color.rgb(45, 56, 52), Color.rgb(108, 116, 107), 1f)
        val current = f?.currentTime?.plusSeconds(
            ((SystemClock.elapsedRealtime() - fetchClock) / 1000).coerceAtLeast(0L))
            ?: LocalDateTime.now()
        val percent = if (rising != null && setting != null && setting.isAfter(rising)) {
            val total = ChronoUnit.MINUTES.between(rising, setting).coerceAtLeast(1)
            val elapsed = ChronoUnit.MINUTES.between(rising, current)
            (elapsed.toFloat() / total.toFloat()).coerceIn(0f, 1f)
        } else 0f
        if (percent > 0f) rounded(c, 54f, 1366f, 757f * percent, 14f, 7f, neon, null, glow = 0f)
        p.color = Color.rgb(3, 16, 8); p.style = Paint.Style.FILL
        p.setShadowLayer(6f, 0f, 0f, neon)
        c.drawCircle(54f + 757f * percent, 1373f, 12f, p)
        p.clearShadowLayer()
        p.style = Paint.Style.STROKE; p.strokeWidth = 3.7f; p.color = neon
        c.drawCircle(54f + 757f * percent, 1373f, 12f, p)
        p.style = Paint.Style.FILL
        text(c, "Тривалість дня", 54f, 1431f, 18f, muted)
        val duration = if (rising == null || setting == null) 0 else ChronoUnit.MINUTES.between(rising, setting).coerceAtLeast(0)
        text(c, if (duration == 0L) "—" else "${duration/60} год ${duration%60} хв",
            54f, 1460f, 23f, white, true)
        text(c, "Зараз", 461f, 1431f, 18f, muted, false, Paint.Align.CENTER)
        text(c, current.format(DateTimeFormatter.ofPattern("HH:mm")), 461f, 1460f,
            23f, white, true, Paint.Align.CENTER)
        val next = if (rising != null && setting != null) {
            if (current.isBefore(rising)) rising else if (current.isAfter(setting)) rising.plusDays(1) else setting
        } else null
        text(c, if (rising != null && setting != null && current.isAfter(rising) && current.isBefore(setting))
            "До заходу" else "До сходу", 810f, 1431f, 18f, muted, false, Paint.Align.RIGHT)
        val remaining = next?.let { ChronoUnit.MINUTES.between(current, it).coerceAtLeast(0) }
        text(c, if (remaining==null) "—" else "${remaining/60} год ${remaining%60} хв",
            810f, 1460f, 23f, white, true, Paint.Align.RIGHT)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val sc = width / 864f
        val px = event.x / sc
        val py = event.y / sc
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = px; downY = py; moving = false; return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(px-downX)>15f || abs(py-downY)>15f) moving = true
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = px-downX; val dy = py-downY
                if (moving && abs(dx)>32f && abs(dx)>abs(dy)) {
                    when {
                        downY in hoursStartY..820f -> {
                            hourlyShift = (hourlyShift + if (dx < 0f) 3 else -3).coerceIn(0, 16)
                            invalidate()
                        }
                        downY in daysStartY..1158f -> {
                            dailyShift = (dailyShift + if (dx < 0f) 2 else -2).coerceIn(0, 7)
                            invalidate()
                        }
                    }
                } else if (moving && dy>82f && dy>abs(dx)) {
                    callbacks?.refresh()
                } else if (!moving || abs(dx) < 15f && abs(dy) < 15f) {
                    when {
                        downY in 35f..108f && downX in 583f..846f -> {
                            val prefs=context.getSharedPreferences("weather_prefs",Context.MODE_PRIVATE)
                            val enabled=prefs.getBoolean("show_fog_risk",false)
                            prefs.edit().putBoolean("show_fog_risk",!enabled).apply()
                            invalidate()
                        }
                        downY in 0f..122f -> callbacks?.openSettings()
                        downY in 125f..535f -> callbacks?.openHours()
                        downY in 550f..820f -> callbacks?.openHours()
                        downY in 837f..1159f -> {
                            if (downX > 670f && downY < 901f) {
                                dailyShift=(dailyShift+2).coerceIn(0,7); invalidate()
                            } else if (downY > daysStartY) {
                                val slot=((downX-31f)/115.2f).toInt()
                                val dayIdx=(slot+dailyShift).coerceIn(0,13)
                                forecast?.days?.getOrNull(dayIdx)?.let {
                                    callbacks?.openDay(it, dayIdx < 7)
                                }
                            }
                        }
                    }
                    performClick()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
