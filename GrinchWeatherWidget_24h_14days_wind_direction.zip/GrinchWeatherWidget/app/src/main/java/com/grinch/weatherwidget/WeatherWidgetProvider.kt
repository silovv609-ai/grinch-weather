package com.grinch.weatherwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class WeatherWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, manager, it) }
    }

    companion object {
        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
            val city = prefs.getString("city_$widgetId", null)
            val views = RemoteViews(context.packageName, R.layout.widget_weather)
            views.setTextViewText(R.id.cityText, city ?: "Оберіть місто в налаштуваннях")
            views.setTextViewText(R.id.tempText, "--°")
            views.setTextViewText(R.id.conditionText, if (city == null) "Налаштуйте віджет" else "Завантажуємо погоду…")
            views.setTextViewText(R.id.hourlyWindText, "Завантажуємо погодинний прогноз…")
            views.setTextViewText(R.id.dailyText, "Завантажуємо прогноз на 14 днів…")
            manager.updateAppWidget(widgetId, views)
            if (city.isNullOrBlank()) return

            thread {
                try {
                    val geoUrl = URL("https://geocoding-api.open-meteo.com/v1/search?name=" +
                        URLEncoder.encode(city, "UTF-8") + "&count=1&language=uk&format=json")
                    val geo = JSONObject(geoUrl.readText())
                    val results = geo.optJSONArray("results")
                    if (results == null || results.length() == 0) {
                        views.setTextViewText(R.id.conditionText, "Місто не знайдено")
                        views.setTextViewText(R.id.hourlyWindText, "")
                        views.setTextViewText(R.id.dailyText, "")
                        manager.updateAppWidget(widgetId, views)
                        return@thread
                    }
                    val place = results.getJSONObject(0)
                    val lat = place.getDouble("latitude")
                    val lon = place.getDouble("longitude")
                    val shownCity = place.optString("name", city)
                    val weatherUrl = URL(
                        "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m" +
                        "&hourly=wind_speed_10m,wind_direction_10m,temperature_2m,weather_code" +
                        "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,wind_direction_10m_dominant,weather_code" +
                        "&wind_speed_unit=ms&forecast_days=14&timezone=auto"
                    )
                    val root = JSONObject(weatherUrl.readText())
                    val current = root.getJSONObject("current")
                    val temp = current.getDouble("temperature_2m").roundToInt()
                    val feels = current.getDouble("apparent_temperature").roundToInt()
                    val wind = current.getDouble("wind_speed_10m")
                    val direction = current.getDouble("wind_direction_10m")
                    val code = current.getInt("weather_code")
                    val isDay = current.optInt("is_day", 1) == 1
                    val (label, icon) = condition(code, isDay)

                    val hourly = root.getJSONObject("hourly")
                    val times = hourly.getJSONArray("time")
                    val winds = hourly.getJSONArray("wind_speed_10m")
                    val dirs = hourly.getJSONArray("wind_direction_10m")
                    val temps = hourly.getJSONArray("temperature_2m")
                    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")
                    val now = LocalDateTime.parse(current.getString("time"), formatter)
                    var start = 0
                    for (i in 0 until times.length()) {
                        val t = LocalDateTime.parse(times.getString(i), formatter)
                        if (!t.isBefore(now)) { start = i; break }
                    }
                    val hourlyText = StringBuilder()
                    for (offset in 0 until 24) {
                        val i = start + offset
                        if (i >= times.length()) break
                        val t = LocalDateTime.parse(times.getString(i), formatter)
                        val hour = t.format(DateTimeFormatter.ofPattern("HH:mm"))
                        val windVal = winds.optDouble(i, Double.NaN)
                        val dirVal = dirs.optDouble(i, Double.NaN)
                        val tempVal = temps.optDouble(i, Double.NaN)
                        if (windVal.isNaN() || dirVal.isNaN()) continue
                        hourlyText.append(hour)
                            .append("   ").append(directionArrow(dirVal))
                            .append("   ").append(String.format(Locale.US, "%.1f", windVal))
                            .append(" м/с")
                            .append("   ·   ").append(tempVal.roundToInt()).append("°")
                        if (offset < 23) hourlyText.append('\n')
                    }

                    val daily = root.getJSONObject("daily")
                    val dates = daily.getJSONArray("time")
                    val maxTemps = daily.getJSONArray("temperature_2m_max")
                    val minTemps = daily.getJSONArray("temperature_2m_min")
                    val rain = daily.getJSONArray("precipitation_probability_max")
                    val maxWind = daily.getJSONArray("wind_speed_10m_max")
                    val dominantDir = daily.getJSONArray("wind_direction_10m_dominant")
                    val codes = daily.getJSONArray("weather_code")
                    val dayFmt = DateTimeFormatter.ofPattern("dd.MM")
                    val dailyText = StringBuilder()
                    for (i in 0 until dates.length()) {
                        val date = LocalDate.parse(dates.getString(i))
                        val maxW = maxWind.optDouble(i, Double.NaN)
                        val dir = dominantDir.optDouble(i, Double.NaN)
                        dailyText.append(date.format(dayFmt))
                            .append("   ").append(directionArrow(dir))
                            .append("   ").append(if (maxW.isNaN()) "—" else String.format(Locale.US, "%.1f", maxW))
                            .append(" м/с")
                            .append("   ·   ").append(minTemps.optDouble(i).roundToInt())
                            .append("…").append(maxTemps.optDouble(i).roundToInt()).append("°")
                            .append("   ·   опади ").append(rain.optInt(i, 0)).append("%")
                        if (i < dates.length() - 1) dailyText.append('\n')
                    }

                    val finalViews = RemoteViews(context.packageName, R.layout.widget_weather)
                    finalViews.setTextViewText(R.id.cityText, shownCity)
                    finalViews.setTextViewText(R.id.tempText, "$temp°")
                    finalViews.setTextViewText(R.id.iconText, icon)
                    finalViews.setTextViewText(R.id.conditionText, label)
                    finalViews.setTextViewText(
                        R.id.detailsText,
                        "Вітер ${String.format(Locale.US, "%.1f", wind)} м/с ${directionArrow(direction)}  •  Відчувається $feels°"
                    )
                    finalViews.setTextViewText(R.id.hourlyWindText, hourlyText.toString())
                    finalViews.setTextViewText(R.id.dailyText, dailyText.toString())
                    manager.updateAppWidget(widgetId, finalViews)
                } catch (_: Exception) {
                    views.setTextViewText(R.id.conditionText, "Немає даних. Перевір інтернет")
                    views.setTextViewText(R.id.hourlyWindText, "Не вдалося завантажити погодинний прогноз")
                    views.setTextViewText(R.id.dailyText, "Не вдалося завантажити прогноз на 14 днів")
                    manager.updateAppWidget(widgetId, views)
                }
            }
        }

        private fun directionArrow(degrees: Double): String {
            if (degrees.isNaN()) return "→"
            val arrows = arrayOf("↑", "↗", "→", "↘", "↓", "↙", "←", "↖")
            val index = (((degrees % 360 + 360) % 360) / 45.0).roundToInt() % 8
            return arrows[index]
        }

        private fun condition(code: Int, day: Boolean): Pair<String, String> = when (code) {
            0 -> "Ясно" to if (day) "☀" else "☾"
            1 -> "Переважно ясно" to if (day) "🌤" else "☾"
            2 -> "Мінлива хмарність" to "⛅"
            3 -> "Хмарно" to "☁"
            45, 48 -> "Туман" to "🌫"
            51, 53, 55, 56, 57 -> "Мряка" to "🌦"
            61, 63, 65, 66, 67 -> "Дощ" to "🌧"
            71, 73, 75, 77 -> "Сніг" to "❄"
            80, 81, 82 -> "Зливи" to "🌧"
            85, 86 -> "Снігопад" to "🌨"
            95, 96, 99 -> "Гроза" to "⛈"
            else -> "Поточна погода" to "🌡"
        }

        private fun URL.readText(): String {
            val connection = openConnection() as HttpURLConnection
            connection.connectTimeout = 12000
            connection.readTimeout = 12000
            connection.requestMethod = "GET"
            return try {
                connection.inputStream.bufferedReader().use { it.readText() }
            } finally {
                connection.disconnect()
            }
        }
    }
}
