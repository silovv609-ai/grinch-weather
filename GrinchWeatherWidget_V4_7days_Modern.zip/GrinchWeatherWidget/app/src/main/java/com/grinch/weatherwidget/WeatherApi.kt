package com.grinch.weatherwidget

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.Locale
import kotlin.math.roundToInt

/** Open-Meteo weather values are read using the city's local timezone. */
object WeatherApi {
    data class Hour(
        val time: LocalDateTime,
        val temp: Int,
        val wind: Double,
        val degrees: Double,
        val gust: Double,
        val precipitation: Double,
        val rainChance: Int,
        val code: Int,
        val isDay: Boolean
    )

    data class Day(
        val date: LocalDate,
        val min: Int,
        val max: Int,
        val wind: Double,
        val degrees: Double,
        val rain: Int,
        val precipitation: Double,
        val code: Int
    )

    data class Forecast(
        val city: String,
        val temperature: Int,
        val feelsLike: Int,
        val wind: Double,
        val windDegrees: Double,
        val precipitation: Double,
        val description: String,
        val icon: String,
        val code: Int,
        val isDay: Boolean,
        val currentTime: LocalDateTime,
        val hours: List<Hour>,
        val days: List<Day>
    )

    fun fetch(city: String): Forecast {
        require(city.isNotBlank()) { "Спочатку вибери місто" }
        val geocodeUrl = "https://geocoding-api.open-meteo.com/v1/search" +
            "?name=${URLEncoder.encode(city, "UTF-8")}&count=1&language=uk&format=json"
        val places = JSONObject(readUrl(geocodeUrl)).optJSONArray("results")
        if (places == null || places.length() == 0) {
            throw IllegalArgumentException("Місто не знайдено. Перевір його назву.")
        }
        val place = places.getJSONObject(0)
        val lat = place.getDouble("latitude")
        val lon = place.getDouble("longitude")
        val actualCity = place.optString("name", city)

        val forecastUrl = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m,precipitation" +
            "&hourly=temperature_2m,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,precipitation,precipitation_probability,is_day" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,wind_speed_10m_max,wind_direction_10m_dominant,weather_code" +
            "&wind_speed_unit=ms&precipitation_unit=mm&forecast_days=14&timezone=auto"

        val root = JSONObject(readUrl(forecastUrl))
        val current = root.getJSONObject("current")
        val currentTime = LocalDateTime.parse(current.getString("time"))
        val currentCode = current.getInt("weather_code")
        val isDay = current.optInt("is_day", 1) == 1
        val (description, icon) = condition(currentCode, isDay)

        val hourly = root.getJSONObject("hourly")
        val times = hourly.getJSONArray("time")
        val temperatures = hourly.getJSONArray("temperature_2m")
        val winds = hourly.getJSONArray("wind_speed_10m")
        val directions = hourly.getJSONArray("wind_direction_10m")
        val gusts = hourly.getJSONArray("wind_gusts_10m")
        val amounts = hourly.getJSONArray("precipitation")
        val chances = hourly.getJSONArray("precipitation_probability")
        val codes = hourly.getJSONArray("weather_code")
        val daytimeFlags = hourly.getJSONArray("is_day")
        val hours = mutableListOf<Hour>()
        val firstDate = currentTime.toLocalDate()
        for (i in 0 until times.length()) {
            val time = LocalDateTime.parse(times.getString(i))
            // Exactly seven city-local calendar dates, 24 hourly entries for each date.
            if (time.toLocalDate().isBefore(firstDate)) continue
            if (!time.toLocalDate().isBefore(firstDate.plusDays(7))) break
            hours.add(
                Hour(
                    time,
                    temperatures.getDouble(i).roundToInt(),
                    winds.getDouble(i),
                    directions.getDouble(i),
                    gusts.optDouble(i, 0.0),
                    amounts.optDouble(i, 0.0),
                    chances.optInt(i, 0),
                    codes.getInt(i),
                    daytimeFlags.optInt(i, 1) == 1
                )
            )
        }

        val daily = root.getJSONObject("daily")
        val dates = daily.getJSONArray("time")
        val minTemps = daily.getJSONArray("temperature_2m_min")
        val maxTemps = daily.getJSONArray("temperature_2m_max")
        val maxWinds = daily.getJSONArray("wind_speed_10m_max")
        val mainDirections = daily.getJSONArray("wind_direction_10m_dominant")
        val rainChances = daily.getJSONArray("precipitation_probability_max")
        val rainAmount = daily.getJSONArray("precipitation_sum")
        val dailyCodes = daily.getJSONArray("weather_code")
        val days = mutableListOf<Day>()
        for (i in 0 until minOf(dates.length(), 14)) {
            days.add(
                Day(
                    LocalDate.parse(dates.getString(i)),
                    minTemps.getDouble(i).roundToInt(),
                    maxTemps.getDouble(i).roundToInt(),
                    maxWinds.getDouble(i),
                    mainDirections.getDouble(i),
                    rainChances.optInt(i, 0),
                    rainAmount.optDouble(i, 0.0),
                    dailyCodes.getInt(i)
                )
            )
        }

        return Forecast(
            city = actualCity,
            temperature = current.getDouble("temperature_2m").roundToInt(),
            feelsLike = current.getDouble("apparent_temperature").roundToInt(),
            wind = current.getDouble("wind_speed_10m"),
            windDegrees = current.getDouble("wind_direction_10m"),
            precipitation = current.optDouble("precipitation", 0.0),
            description = description,
            icon = icon,
            code = currentCode,
            isDay = isDay,
            currentTime = currentTime,
            hours = hours,
            days = days
        )
    }

    fun speed(value: Double): String = String.format(Locale.US, "%.1f", value)
    fun mm(value: Double): String = String.format(Locale.US, "%.1f", value)

    /** Open-Meteo degrees point to where wind comes FROM. Our arrow points where it blows TO. */
    fun arrow(fromDegrees: Double): String {
        val arrows = arrayOf("↑", "↗", "→", "↘", "↓", "↙", "←", "↖")
        val towards = (((fromDegrees + 180.0) % 360.0) + 360.0) % 360.0
        return arrows[((towards + 22.5) / 45.0).toInt() % 8]
    }

    fun condition(code: Int, isDay: Boolean = true): Pair<String, String> = when (code) {
        0 -> "Ясно" to if (isDay) "☀" else "☾"
        1 -> "Переважно ясно" to if (isDay) "🌤" else "☾"
        2 -> "Мінлива хмарність" to "⛅"
        3 -> "Хмарно" to "☁"
        45, 48 -> "Туман" to "🌫"
        51, 53, 55, 56, 57 -> "Мряка" to "🌦"
        61, 63, 65, 66, 67 -> "Дощ" to "🌧"
        71, 73, 75, 77 -> "Сніг" to "❄"
        80, 81, 82 -> "Зливи" to "🌧"
        85, 86 -> "Снігопад" to "🌨"
        95, 96, 99 -> "Гроза" to "⛈"
        else -> "Погода" to "☁"
    }

    private fun readUrl(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 12000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Сервер погоди повернув ${connection.responseCode}")
            }
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
