package com.grinch.weatherwidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import java.time.LocalDateTime
import kotlin.math.roundToInt

/** Scrolling 7-day / 168-hour weather timeline drawn in one view for smooth performance. */
class HourlyTimelineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val hours = mutableListOf<WeatherApi.Hour>()
    private var currentTime: LocalDateTime? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = Rect()
    private val density = resources.displayMetrics.density
    private val fontScale = resources.displayMetrics.scaledDensity
    private val column = 112f * density
    private val side = 8f * density
    private val warm = Color.rgb(255, 208, 134)
    private val white = Color.rgb(242, 249, 255)
    private val light = Color.rgb(169, 194, 215)
    private val teal = Color.rgb(136, 222, 234)

    val columnWidthPx: Int get() = column.roundToInt()

    fun setForecast(data: List<WeatherApi.Hour>, now: LocalDateTime) {
        hours.clear()
        hours.addAll(data)
        currentTime = now
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredWidth = (hours.size.coerceAtLeast(3) * column + side * 2).roundToInt()
        val desiredHeight = (348f * density).roundToInt()
        setMeasuredDimension(
            resolveSize(desiredWidth, widthMeasureSpec),
            resolveSize(desiredHeight, heightMeasureSpec)
        )
    }

    private fun cx(index: Int) = side + column * (index + .5f)
    private fun y(dp: Float) = dp * density

    private fun text(canvas: Canvas, value: String, x: Float, y: Float,
                     sp: Float, color: Int, bold: Boolean = false) {
        p.reset()
        p.isAntiAlias = true
        p.color = color
        p.textAlign = Paint.Align.CENTER
        p.textSize = sp * fontScale
        p.typeface = if (bold) android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                     else android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        canvas.drawText(value, x, y, p)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (hours.isEmpty()) {
            text(canvas, "Завантаження прогнозу...", width / 2f, y(175f), 14f, light)
            return
        }
        canvas.getClipBounds(bounds)
        val firstVisible = ((bounds.left - side) / column).toInt().coerceIn(0, hours.lastIndex)
        val lastVisible = ((bounds.right - side) / column).toInt().coerceIn(firstVisible, hours.lastIndex)
        val first = (firstVisible - 2).coerceAtLeast(0)
        val last = (lastVisible + 2).coerceAtMost(hours.lastIndex)

        val minTemp = hours.minOf { it.temp }
        val maxTemp = hours.maxOf { it.temp }
        val tempSpan = (maxTemp - minTemp).coerceAtLeast(3).toFloat()
        fun graphY(t: Int): Float = y(187f) - ((t - minTemp) / tempSpan) * y(38f)

        for (i in first..last) {
            val hour = hours[i]
            val x = cx(i)
            val day = hour.time.toLocalDate()
            val evenDate = (day.toEpochDay() % 2L == 0L)
            if (evenDate) {
                p.color = Color.rgb(29, 45, 62)
                p.style = Paint.Style.FILL
                canvas.drawRect(x - column/2f, 0f, x + column/2f, height.toFloat(), p)
            }
            if (hour.time == currentTime?.withMinute(0)?.withSecond(0)?.withNano(0)) {
                p.color = Color.rgb(47, 78, 91)
                canvas.drawRoundRect(RectF(x-column*.44f, y(6f), x+column*.44f, height-y(7f)),y(16f),y(16f),p)
            }
            if (hour.time.hour == 0 && i > 0) {
                p.color = Color.rgb(67, 98, 118)
                p.strokeWidth = y(1f)
                canvas.drawLine(x-column*.5f, y(14f), x-column*.5f, height-y(14f), p)
            }
            text(canvas, "%02d:00".format(hour.time.hour), x, y(30f), 13f, light)
            WeatherGlyph.draw(canvas, x, y(70f), y(18f), hour.code,
                hour.isDay, p)
            text(canvas, "${hour.temp}°", x, y(127f), 24f, white, true)
        }

        // Temperature curve: a single continuous line across every hour.
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = y(2.5f)
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = warm
        val path = Path()
        val graphStart = (first-1).coerceAtLeast(0)
        val graphEnd = (last+1).coerceAtMost(hours.lastIndex)
        for (i in graphStart..graphEnd) {
            if (i == graphStart) path.moveTo(cx(i), graphY(hours[i].temp))
            else path.lineTo(cx(i), graphY(hours[i].temp))
        }
        canvas.drawPath(path,p)

        for (i in first..last) {
            val hour = hours[i]
            val x = cx(i)
            p.style = Paint.Style.FILL
            p.color = warm
            canvas.drawCircle(x, graphY(hour.temp), y(3f), p)

            // Wind direction arrow: WHITE and points toward wind travel, not origin.
            drawWindArrow(canvas, x - y(21f), y(227f), hour.degrees)
            text(canvas, "${WeatherApi.speed(hour.wind)} м/с", x + y(12f), y(233f), 13f, white, true)

            text(canvas, "ПОРИВИ", x, y(266f), 10f, light, true)
            text(canvas, "${WeatherApi.speed(hour.gust)} м/с", x, y(289f), 15f, teal, true)
            text(canvas, "Опади ${WeatherApi.mm(hour.precipitation)} мм", x, y(315f), 11f, light)
            text(canvas, "${hour.rainChance}%", x, y(336f), 12f, teal, true)
        }
    }

    private fun drawWindArrow(canvas: Canvas, x: Float, y: Float, fromDegrees: Double) {
        val degreesTo = ((fromDegrees + 180.0) % 360.0).toFloat()
        canvas.save()
        canvas.rotate(degreesTo, x, y)
        p.reset()
        p.isAntiAlias = true
        p.color = white
        p.style = Paint.Style.STROKE
        p.strokeWidth = this.y(2f)
        p.strokeCap = Paint.Cap.ROUND
        val length = this.y(11f)
        canvas.drawLine(x, y+length*.55f, x, y-length*.75f,p)
        canvas.drawLine(x,y-length*.75f,x-length*.4f,y-length*.25f,p)
        canvas.drawLine(x,y-length*.75f,x+length*.4f,y-length*.25f,p)
        canvas.restore()
    }
}
